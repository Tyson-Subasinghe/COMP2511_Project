package unsw.dungeon;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ThreadLocalRandom;

import entities.*;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * A JavaFX controller for the dungeon.
 * @author Robert Clifton-Everest
 * Modified by Ian/Tyson
 */
public class DungeonController {

    @FXML
    private GridPane squares;
    
    @FXML
    private GridPane inventoryGrid;
    
    @FXML
    private GridPane goalBar;
    

    private List<ImageView> initialEntities;
    private List<Node> inventory;

    private Player player;
    private Dungeon dungeon;
    
    private Stage lastStage = null;

    public DungeonController(Dungeon dungeon, List<ImageView> initialEntities,
    						 List<Node> inventory) {
        this.dungeon = dungeon;
        this.player = dungeon.getPlayer();
        this.initialEntities = new ArrayList<>(initialEntities);
        this.inventory = new ArrayList<>(inventory);
    }

    @FXML
    public void initialize() {
        Image ground;
        
        // Add the ground first so it is below all other entities
        for (int x = 0; x < dungeon.getWidth(); x++) {
            for (int y = 0; y < dungeon.getHeight(); y++) {
            	
            	//Procedural generation of floor texture
                int random = ThreadLocalRandom.current().nextInt(1,101);
                
                if(random == 1) {
                	ground = new Image("/dirt_3_new.png"); //Diamond
                }else if(random <= 5) {
                	ground = new Image("/dirt_2_new.png"); //Iron
                }else if(random <= 15) {
                	ground = new Image("/dirt_1_new.png"); //Coal
                }else {
                	ground = new Image("/dirt_0_new.png"); //Stone
                }
            	
            	
                squares.add(new ImageView(ground), x, y);
            }
        }

        for (ImageView entity : initialEntities)
            squares.getChildren().add(entity);
        
        for (Node invItem : inventory) {
        	inventoryGrid.getChildren().add(invItem);
        }
        
        setupGoalDisplay();
    }
    
    private Label colourLabel(String line) {
    	Label label = new Label();
    	label.setText(line);
    	if (line.endsWith(":")) {
        	label.setTextFill(Color.WHITE);
    	} else if (line.endsWith("(Complete)")) { 
        	label.setTextFill(Color.LIME);
    	} else if (line.endsWith("(0 remaining).")) {
    		label.setTextFill(Color.LIME);
    	} else if (!line.endsWith("remaining).") &&
    			   line.endsWith(").")) {
    		Pattern p = Pattern.compile(".*\\(([0-9]+)/([0-9]+)\\)\\.");
    		Matcher m = p.matcher(line);
    		m.matches();
    		if (m.group(1).equals(m.group(2))) {
	        	label.setTextFill(Color.LIME);
    		} else {
	        	label.setTextFill(Color.RED);
    		}
    	} else {
        	label.setTextFill(Color.RED);
    	}
    	
    	return label;
    }
        
    private void setupGoalDisplay() {
        dungeon.getGoal().notifyGoal("");
        String goalText = dungeon.getGoal().getGoalProgress();
        
        
        int lines = 0;
        for (String line : goalText.split("\n")) {
        	Label label = new Label();
        	label.setText(line);
        	if (line.endsWith(":")) {
            	label.setTextFill(Color.WHITE);
        	} else {
            	label.setTextFill(Color.RED);
        	}
        	
        	goalBar.add(label, 0, lines);
        	
        	lines++;
        }
        
        
        StringProperty message = dungeon.getGoal().getObservableProgress();
        message.addListener(new ChangeListener<String>() {
    		@Override
    		public void changed(ObservableValue<? extends String> observable,
                    String oldValue, String newValue) {
    			goalBar.getChildren().clear();
    			
    			int lines = 0;
    	        for (String line : newValue.split("\n")) {
    	        	Label label = colourLabel(line);
    	        	
    	        	goalBar.add(label, 0, lines);
    	        	
    	        	lines++;
    	        }
    		}
    	});
    }

    @FXML
    public void handleKeyPress(KeyEvent event) {
    	lastStage = (Stage)((Node) event.getSource()).getScene().getWindow();
    	
    	
    	
        switch (event.getCode()) {
        case UP:
        	if(isConfused()) {
        		confusionMove();
        		break;
        	}
            player.moveUp();
            break;
        case DOWN:
        	if(isConfused()) {
        		confusionMove();
        		break;
        	}
            player.moveDown();
            break;
        case LEFT:
        	if(isConfused()) {
        		confusionMove();
        		break;
        	}
            player.moveLeft();
            break;
        case RIGHT:
        	if(isConfused()) {
        		confusionMove();
        		break;
        	}
            player.moveRight();
            break;
        case R:
        	dungeon.restartLevel();
        	break;
        	
        case K:
        	dungeon.notifyDeath();
        	break;
        
        case B:
        	//Place a bomb
        	player.placeBomb(player.getX(), player.getY());
        	break;
        	
        case W:
            player.attackUp();
            
            break;
        case S:
            player.attackDown();
            
            break;
        case A:
            player.attackLeft();
           
            break;
        case D:
            player.attackRight();
            break;
            
            
        default:
            break;
        }
    }
    
    public void addEntity(ImageView entity) {
    	squares.getChildren().add(entity);
    }
    
    public void removeEntity(ImageView entity) {
    	squares.getChildren().remove(entity);
    }
    
    public Stage getLastStage() {
    	return lastStage;
    }
    
    public void confusionMove() {
    	player.confusionMove();
    }
    
    public boolean isConfused() {
    	if(player.getInventory().getConfusionUses()>0 && player.getInventory().getConfusionStatus()){
    		return true;
    	}else {
    		return false;
    	}
    	
    }

}

