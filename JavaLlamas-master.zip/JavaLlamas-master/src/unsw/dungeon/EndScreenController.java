package unsw.dungeon;

import java.util.ArrayList;
import java.util.List;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 * A JavaFX controller for the dungeon.
 * @author Robert Clifton-Everest
 *
 */
public class EndScreenController {
	@FXML
    private GridPane EndScreen;

    @FXML
    private GridPane ButtonBar;
    
    private String message = "<No message set>";
    
    private List<Button> buttons = new ArrayList<>();
    
    public EndScreenController(List<Button> buttons, String message) {
    	this.buttons = new ArrayList<Button>(buttons);
    	this.message = message;
    }
    
    @FXML
    public void initialize() {
    	Label msgLbl = new Label();
    	msgLbl.setText(message);
    	msgLbl.setWrapText(true);
    	
    	EndScreen.add(msgLbl, 0, 0);
    	
    	int i = 0;
    	for (Button button: buttons) {
    		EventHandler<ActionEvent> oldAction = button.getOnAction();
    		
    		// Close the window when a button is clicked.
    		button.setOnAction(actionEvent -> {
    			Stage currStage = (Stage)((Node) actionEvent.getSource()).getScene().getWindow();
    			currStage.close();
    			oldAction.handle(actionEvent);
        	});
    		ButtonBar.add(button, i, 0);
    		i++;
    	}
    }
}

