package unsw.dungeon;

import java.io.FileNotFoundException;
import entities.*;
import entities.enemies.Enemy;
import entities.enemies.Gnome;
import entities.enemies.Hound;
import entities.enemies.TrappedTreasure;
import entities.enemies.Troll;
import entities.goalComponents.Boulder;
import entities.goalComponents.Exit;
import entities.goalComponents.Switch;
import entities.goalComponents.Treasure;
import entities.items.Arrow;
import entities.items.Bomb;
import entities.items.Bow;
import entities.items.Confusion;
import entities.items.Invincibility;
import entities.items.Key;
import entities.items.LockedDoor;
import entities.items.Sword;
import goals.BouldersGoal;
import goals.EnemiesGoal;
import goals.Goal;
import goals.MazeGoal;
import goals.MultiGoalAnd;
import goals.MultiGoalOr;
import goals.TreasureGoal;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.fxml.FXMLLoader;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 * Loads a dungeon from a .json file.
 *
 * By extending this class, a subclass can hook into entity creation. This is
 * useful for creating UI elements with corresponding entities.
 *
 * @author Robert Clifton-Everest
 *
 */
public abstract class DungeonLoader {
    private List<JSONObject> dungeon_jsons;// List of all opened dungeons' JSONs
    
	private Dungeon currentDungeon = null; // Current dungeon
	private int currDungIndex = 0; 		   // Current dungeon index

    public DungeonLoader(List<String> filenames) throws FileNotFoundException {
    	dungeon_jsons = new ArrayList<JSONObject>();
    	
    	for (String filename: filenames) {
    		JSONObject json = new JSONObject(new JSONTokener(new FileReader("dungeons/" + filename)));
    		dungeon_jsons.add(json);
    	}
    }

    /**
     * Parses the JSON to create a dungeon.
     * @return
     */public void loadLevel() {
    	if (currentDungeon == null) {
    		//Convert the file to a level
    		currentDungeon = load(dungeon_jsons.get(currDungIndex));
    	}
    }
    
    public Dungeon getCurrDungeon() {
    	return currentDungeon;
    }
    
    public void reloadCurr() {
    	currentDungeon = load(dungeon_jsons.get(currDungIndex));
    }
    
    public boolean goToNextDungeon() {
    	if (currDungIndex + 1 >= dungeon_jsons.size()) {
    		return false;
    	}

    	currDungIndex++;
    	reloadCurr();
    	return currentDungeon != null;
    }
    
    public void handleCompletedLevel(String message) {
    	// Create end screen and allow user to navigate levels
    	
    	List<Button> buttons = new ArrayList<Button>();
    	
    	
    	Button quit = new Button("Quit");
    	quit.setOnAction(actionEvent -> {
    		System.exit(0);
    	});
    	GridPane.setHalignment(quit, HPos.CENTER);
    	GridPane.setValignment(quit, VPos.CENTER);
    	buttons.add(quit);
    	
    	
    	Button restart = new Button("Replay Level");
    	restart.setOnAction(actionEvent -> {
    		loadLevel();
        	refreshDungeon();
    	});
    	GridPane.setHalignment(restart, HPos.CENTER);
    	GridPane.setValignment(restart, VPos.CENTER);
    	buttons.add(restart);
    	
    	
    	if (currDungIndex + 1 != dungeon_jsons.size()) {
	    	Button contButton = new Button("Continue");
	    	contButton.setOnAction(actionEvent -> {
	    		if (!goToNextDungeon()) {
		    		System.exit(0);
	    		}
	        	refreshDungeon();
	    	});
	    	GridPane.setHalignment(contButton, HPos.CENTER);
	    	GridPane.setValignment(contButton, VPos.CENTER);
	    	buttons.add(contButton);
    	}
    	
    	
    	// Actually render end screen and display it.
    	try {
	    	Stage stage = new Stage();
	    	stage.setTitle("End Screen");
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("EndScreen.fxml"));
	    	
	    	EndScreenController controller = new EndScreenController(buttons, message);
	    	
	    	loader.setController(controller);
	        Parent root = loader.load();
	        Scene scene = new Scene(root);
	        root.requestFocus();
	        stage.setScene(scene);
	        stage.show();
    	}
    	catch (IOException e) {
    		e.printStackTrace();
    	}
    }
    
    // As above, but with different labels to account for the fact that player died.
    public void handleDeath(String message) {
    	List<Button> buttons = new ArrayList<Button>();
    	
    	
    	Button quit = new Button("Quit");
    	quit.setOnAction(actionEvent -> {
    		System.exit(0);
    	});
    	GridPane.setHalignment(quit, HPos.CENTER);
    	GridPane.setValignment(quit, VPos.CENTER);
    	buttons.add(quit);
    	
    	
    	Button restart = new Button("Retry Level");
    	restart.setOnAction(actionEvent -> {
    		loadLevel();
        	refreshDungeon();
    	});
    	GridPane.setHalignment(restart, HPos.CENTER);
    	GridPane.setValignment(restart, VPos.CENTER);
    	buttons.add(restart);
    	
    	
    	if (currDungIndex + 1 != dungeon_jsons.size()) {
	    	Button contButton = new Button("Skip level");
	    	contButton.setOnAction(actionEvent -> {
	    		if (!goToNextDungeon()) {
		    		System.exit(0);
	    		}
	        	refreshDungeon();
	    	});
	    	GridPane.setHalignment(contButton, HPos.CENTER);
	    	GridPane.setValignment(contButton, VPos.CENTER);
	    	buttons.add(contButton);
    	}
    	
    	
    	try {
	    	Stage stage = new Stage();
	    	stage.setTitle("End Screen");
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("EndScreen.fxml"));
	    	
	    	EndScreenController controller = new EndScreenController(buttons, message);
	    	
	    	loader.setController(controller);
	        Parent root = loader.load();
	        Scene scene = new Scene(root);
	        root.requestFocus();
	        stage.setScene(scene);
	        stage.show();
    	}
    	catch (IOException e) {
    		e.printStackTrace();
    	}
    }
    	
    public abstract void refreshDungeon();
    
    // Create a Dungeon using the json specification.
    public Dungeon load(JSONObject json) {

        int width = json.getInt("width");
        int height = json.getInt("height");

        Dungeon dungeon = new Dungeon(this, width, height);

        JSONArray jsonEntities = json.getJSONArray("entities");

        for (int i = 0; i < jsonEntities.length(); i++) {
            loadEntity(dungeon, jsonEntities.getJSONObject(i));
        }
        
        loadGoal(dungeon,json);//Loads the goal 
        
        // Load inventory bar
        Player p = dungeon.getPlayer();
        loadInvItem(p.getInventory().getObservableSword(), 0, p);
        loadInvItem(p.getInventory().getObservableBomb(), 1, p);
        loadInvItem(p.getInventory().getObservableTreas(), 2, p);
        loadInvItem(p.getInventory().getObservableInvinc(), 3, p);
        loadInvItem(p.getInventory().getObservableConfusion(), 4, p);
        loadInvItem(p.getInventory().getObservableKey(), 5, p);
        
        return dungeon;
    }

    protected abstract void loadInvItem(BooleanProperty hasKey, int index, Player p);

	protected abstract void loadInvItem(IntegerProperty uses, int index, Player p);

	// Loads a single entity to the dungeon, specified by the json.
	protected void loadEntity(Dungeon dungeon, JSONObject json) {
        String type = json.getString("type");
        int x = json.getInt("x");
        int y = json.getInt("y");

        Entity entity = null;
        switch (type) {
        case "player":
            Player player = new Player(dungeon, x, y);
            dungeon.setPlayer(player);
            onLoad(player);
            entity = player;
            break;
        case "wall":
            Wall wall = new Wall(dungeon, x, y);
            onLoad(wall);
            entity = wall;
            break;
        case "exit":
        	Exit exit = new Exit(dungeon, x, y);
        	onLoad(exit);
        	entity = exit;
        	break;
        case "boulder":
        	Boulder boulder = new Boulder(dungeon, x, y);
        	onLoad(boulder);
        	entity = boulder;
        	break;
        case "switch":
        	Switch switchTile = new Switch(dungeon, x, y);
        	onLoad(switchTile);
        	entity = switchTile;
        	break;
        case "enemy":
        	Enemy enemy = new Enemy(dungeon, x, y);
        	onLoad(enemy);
        	entity = enemy;
        	break;
        case "hound":
        	Hound hound = new Hound(dungeon, x, y);
        	onLoad(hound);
        	entity = hound;
        	break;
        case "sword":
        	Sword sword = new Sword(dungeon, x, y);
        	onLoad(sword);
        	entity = sword;
        	break;
        case "treasure":
        	Treasure treasure = new Treasure(dungeon, x, y);
        	onLoad(treasure);
        	entity = treasure;
        	break;
        case "trappedtreasure":
        	TrappedTreasure trappedTreasure = new TrappedTreasure(dungeon, x, y);
        	onLoad(trappedTreasure);
        	entity = trappedTreasure;
        	break;
        case "bomb":
        	Bomb bomb = new Bomb(dungeon, x, y);
        	onLoad(bomb);
        	entity = bomb;
        	break;
        case "invincibility":
        	Invincibility invincibility= new Invincibility(dungeon, x, y);
        	onLoad(invincibility);
        	entity = invincibility;
        	break;	
        case "confusion":
        	Confusion confusion= new Confusion(dungeon, x, y);
        	onLoad(confusion);
        	entity = confusion;
        	break;
        case "door":
        	int doorId = json.getInt("id");
        	LockedDoor ld = new LockedDoor(dungeon, x, y, doorId);
        	onLoad(ld);
        	entity = ld;
        	break;
        case "key":
        	int keyId = json.getInt("id");
        	Key key = new Key(dungeon, x, y, keyId);
        	onLoad(key);
        	entity = key;
        	break;
        case "bow":
        	Bow bow = new Bow(dungeon, x, y);
        	onLoad(bow);
        	entity = bow;
        	break;
        case "arrow":
        	Arrow arrow = new Arrow(dungeon, x, y);
        	onLoad(arrow);
        	entity = arrow;
        	break;
        case "troll":
        	Troll troll = new Troll(dungeon, x, y);
        	onLoad(troll);
        	entity = troll;
        	break;
        default:
        	System.err.println("Unknown entity in JSON. Not adding entity.");
        	return;
        }
       
        dungeon.addEntity(entity);
    }
	
	// Wrapper for the recursive generate goal function
	private void loadGoal(Dungeon dungeon, JSONObject json) {
    	json = json.getJSONObject("goal-condition");
    	
    	Goal goal = generateGoal(json);
    	goal.initCounts(dungeon);
    	
    	dungeon.setGoal(goal);
    }
    
	// Generates a goal from the json provided
    public static Goal generateGoal(JSONObject json) {
    	String goalType =json.getString("goal");
        
        if (goalType.equals("OR") || goalType.equals("AND")) {
        	// Set up multi-goals recursively
        	List<Goal> subgoals = new ArrayList<Goal>();
        	JSONArray subgoals_json = json.getJSONArray("subgoals");
        	for (int i = 0; i < subgoals_json.length(); i++) {
        		JSONObject subJson = subgoals_json.getJSONObject(i);
        		subgoals.add(generateGoal(subJson));
        	}
        	
        	if (goalType.equals("OR")) {
            	return new MultiGoalOr(subgoals);
        	} else {
            	return new MultiGoalAnd(subgoals);
        	}
        } else {
        	switch(goalType) {
        	case "exit":
        		return new MazeGoal();
        	case "boulders":
        		return new BouldersGoal();
        	case "enemies":
        		return new EnemiesGoal();
        	case "treasure":
        		return new TreasureGoal();
        	default:
        		System.out.println("Unknown goal type specified. Please correct the JSON.");
        		System.exit(0);
        	}
        }
        
        return null;
    }

    public abstract void onLoad(Entity player);

    public abstract void onLoad(Wall wall);

    public abstract void onLoad(Exit exit);
    
    public abstract void onLoad(Boulder boulder);
    
    public abstract void onLoad(Switch tile);
    
    public abstract void onLoad(Treasure treasure);
    
    public abstract void onLoad(Sword sword);
    
    public abstract void onLoad(Enemy enemy);
    
    public abstract void onLoad(Bomb bomb);
    
    public abstract void onLoad(Invincibility invincibility);
    
	public abstract void onLoad(LockedDoor door);

	public abstract void onLoad(Key key);
	
	public abstract void onLoad(Arrow arrow);
	
	public abstract void onLoad(Bow bow);
	
	public abstract void onLoad(Hound hound);
	
	public abstract void onLoad(Confusion confusion);
	
	public abstract void onLoad(Gnome gnome);
	
	public abstract void onLoad(TrappedTreasure trappedTreasure);
	
	public abstract void onLoad(Troll troll);
    
    //Only accessible by Dungeon class, this is for de-rendering picked up object
    protected abstract void derender(Entity entity);
    
    protected abstract void spawnBomb(Bomb bomb); //For bomb spawning

    protected abstract void spawnArrow(Arrow arrow);
    
    protected abstract void spawnGnome(Gnome gnome);
}
