package unsw.dungeon;

import java.io.FileNotFoundException;
import entities.*;
import entities.enemies.Enemy;
import entities.enemies.Gnome;
import entities.enemies.Hound;
import entities.enemies.TrappedTreasure;
import entities.enemies.Troll;
import entities.goalComponents.Boulder;
import entities.goalComponents.Exit;
import entities.goalComponents.Switch;
import entities.goalComponents.Treasure;
import entities.items.Arrow;
import entities.items.Bomb;
import entities.items.Bow;
import entities.items.Confusion;
import entities.items.Invincibility;
import entities.items.Key;
import entities.items.LockedDoor;
import entities.items.Sword;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXMLLoader;
import javafx.geometry.HPos;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * A DungeonLoader that also creates the necessary ImageViews for the UI,
 * connects them via listeners to the model, and creates a controller.
 * @author Robert Clifton-Everest
 * Modified by Ian/Tyson
 */
public class DungeonControllerLoader extends DungeonLoader {

    private List<ImageView> entities;
    private List<Node> invItems;
    
    private List<Integer> keyIds;

    //Images
    private Image playerImage;
    private Image wallImage;
    private Image mossyWallImage;
    private Image webWallImage;
	private Image exitImage;
	private Image boulderImage;
	private Image switchImage;
	private Image treasureImage;
	private Image swordImage;
	private Image enemyImage;
	private Image bombImage;
	private List<Image> bombFuseSequence;
	private Image invincibilityImage;
	private Image confusionImage;
	private Image closedDoorImage;
	private Image blueClosedDoorImage;
	private Image redClosedDoorImage;
	private Image openDoorImage;
	private Image keyImage;
	private Image blueKeyImage;
	private Image redKeyImage;
	private Image invOverlayImage;
	private Image bowImage;
	private Image arrowImage;
	private Image houndImage;
	private Image gnomeImage;
	private Image trollStanding;
	private List<Image> trollRaises;
	private List<Image> trollAttacks;

	
	private DungeonController prevController;


    public DungeonControllerLoader(List<String> filenames)
            throws FileNotFoundException {
        super(filenames);
        entities = new ArrayList<>();
        invItems = new ArrayList<>();
        keyIds = new ArrayList<>();
        
        playerImage = new Image("/human_new.png");
        wallImage = new Image("/brick_brown_0.png");
        mossyWallImage = new Image ("/brick_brown_1.png");
        webWallImage = new Image ("/brick_brown_2.png");
        exitImage = new Image("/exit.png");
        boulderImage = new Image("/boulder.png");
        switchImage = new Image("/pressure_plate.png");
        treasureImage = new Image("/gold_pile.png");
        swordImage = new Image("/greatsword_1_new.png");
        enemyImage = new Image("/deep_elf_master_archer.png");
        bombImage = new Image("/bomb_unlit.png");
        invincibilityImage = new Image("/brilliant_blue_new.png");
        closedDoorImage = new Image("/yellow_closed_door.png");
        blueClosedDoorImage = new Image("/blue_closed_door.png");
        redClosedDoorImage = new Image("/red_closed_door.png");
        openDoorImage = new Image("/open_door.png");
        keyImage = new Image("/key.png");
        blueKeyImage = new Image("/blueKey.png");
        redKeyImage = new Image("/redKey.png");
        bowImage = new Image("/BowNArrow.png");
        arrowImage = new Image("/Arrow.png");
        houndImage = new Image("/hound.png");
        gnomeImage = new Image("/gnome.png");
        
        bombFuseSequence = new ArrayList<Image>();
        bombFuseSequence.add(new Image("/bomb_lit_4.png"));
        bombFuseSequence.add(new Image("/bomb_lit_3.png"));
        bombFuseSequence.add(new Image("/bomb_lit_2.png"));
        bombFuseSequence.add(new Image("/bomb_lit_1.png"));
        
        confusionImage = new Image("/bubbly.png");
        invOverlayImage = new Image("/ItemFrame.png");

        trollStanding = new Image("/TrollStanding.png");
        
        trollRaises = new ArrayList<Image>();
        trollRaises.add(new Image("TrollRaiseUp.png"));
        trollRaises.add(new Image("TrollRaiseDown.png"));
        trollRaises.add(new Image("TrollRaiseLeft.png"));
        trollRaises.add(new Image("TrollRaiseRight.png"));
        
        trollAttacks = new ArrayList<Image>();
        trollAttacks.add(new Image("TrollAttackUp.png"));
        trollAttacks.add(new Image("TrollAttackDown.png"));
        trollAttacks.add(new Image("TrollAttackLeft.png"));
        trollAttacks.add(new Image("TrollAttackRight.png"));
    }
    
    // ----------------
    // onLoad functions
    // ----------------

    @Override
    public void onLoad(Entity player) {
        ImageView view = new ImageView(playerImage);
        addEntity(player, view);
    }

    @Override
    public void onLoad(Wall wall) {
    	//Generate a number between 1 and 100
    	int random = ThreadLocalRandom.current().nextInt(1,101);
    	ImageView view;
    	//Procedural image generation:
    	if(random <= 1) {
    		view = new ImageView(webWallImage);
    	}else if(random <= 25) {
    		view = new ImageView(mossyWallImage);
    	}else {
    		view = new ImageView(wallImage);
    	}
        
        addEntity(wall, view);
    }

    @Override
    public void onLoad(Exit exit) {
        ImageView view = new ImageView(exitImage);
        addEntity(exit, view);
    }
    
    @Override
    public void onLoad(Boulder boulder) {
        ImageView view = new ImageView(boulderImage);
        addEntity(boulder, view);
    }
    
    @Override
    public void onLoad(Switch tile) {
        ImageView view = new ImageView(switchImage);
        addEntity(tile, view);
    }
    @Override
    public void onLoad(Treasure treasure) {
        ImageView view = new ImageView(treasureImage);
        addEntity(treasure, view);
    }
    @Override
    public void onLoad(Sword sword) {
        ImageView view = new ImageView(swordImage);
        addEntity(sword, view);
    }
    @Override
    public void onLoad(Enemy enemy) {
        ImageView view = new ImageView(enemyImage);
        addEntity(enemy, view);
    }
    
    public void onLoad(Hound hound) {
        ImageView view = new ImageView(houndImage);
        addEntity(hound, view);
    }
    
    public void onLoad(Gnome gnome) {
        ImageView view = new ImageView(gnomeImage);
        addEntity(gnome, view);
    }
    
    public void onLoad(TrappedTreasure trappedTreasure) {
        ImageView view = new ImageView(treasureImage);
        addEntity(trappedTreasure, view);
    }
    
    @Override
    public void onLoad(Arrow arrow) {
        ImageView view = new ImageView(arrowImage);
        addEntity(arrow, view);
    }
    
    @Override
    public void onLoad(Bow bow) {
        ImageView view = new ImageView(bowImage);
        addEntity(bow, view);
    }
    
    @Override
    public void onLoad(Bomb bomb) {
        if (bomb.getActive()) {
        	ImageView view = new ImageView(bombFuseSequence.get(3));
        	addEntity(bomb, view);
        	trackFuse(bomb, view);
        	prevController.addEntity(view);
        } else {
        	ImageView view = new ImageView(bombImage);
            addEntity(bomb, view);
        }
    }
    
    @Override
    public void onLoad(Invincibility invincibility) {
        ImageView view = new ImageView(invincibilityImage);
        addEntity(invincibility, view);
    }
    
    @Override
    public void onLoad(Confusion confusion) {
        ImageView view = new ImageView(confusionImage);
        addEntity(confusion, view);
    }
    
    @Override
    public void onLoad(LockedDoor door) {
    	if (!keyIds.contains(door.getId())) {
        	keyIds.add(door.getId());
    	}

    	ImageView view = new ImageView(redClosedDoorImage);
    	
    	switch(keyIds.indexOf(door.getId())) {
    	case 0:
    		view = new ImageView(closedDoorImage);
    		break;
    	case 1:
    		view = new ImageView(blueClosedDoorImage);
    		break;
    	}
    	
    	trackOpened(door, view);
    	addEntity(door, view);
    }
    
    @Override
    public void onLoad(Key key) {
    	if (!keyIds.contains(key.getId())) {
        	keyIds.add(key.getId());
    	}

    	ImageView view = new ImageView(redKeyImage);
    	
    	switch(keyIds.indexOf(key.getId())) {
    	case 0:
    		view = new ImageView(keyImage);
    		break;
    	case 1:
    		view = new ImageView(blueKeyImage);
    		break;
    	}
    	
    	addEntity(key, view);
    }
    
    @Override
    public void onLoad(Troll troll) {
    	ImageView view = new ImageView(trollStanding);
    	
    	trackTroll(troll, view);
    	addEntity(troll, view);
    }
    
    // --------------------------
    // Loading inventory textures
    // --------------------------
    
    @Override
    public void loadInvItem(IntegerProperty uses, int index, Player p) {
    	// Define the texture
        ImageView item = new ImageView(playerImage);
    	switch(index) {
    	case 0:
    		item = new ImageView(swordImage);
    		break;
    	case 1:
    		item = new ImageView(bombImage);
    		break;
    	case 2:
    		item = new ImageView(treasureImage);
    		break;
    	case 3:
    		item = new ImageView(invincibilityImage);
    		break;
    	case 4:
    		item = new ImageView(confusionImage);
    		break;
    	}
    	GridPane.setColumnIndex(item, index);
    	
    	ImageView overlay = new ImageView(invOverlayImage);
    	GridPane.setColumnIndex(overlay, index);
    	
    	Label label = new Label("x0");
    	GridPane.setColumnIndex(label, index);
    	GridPane.setHalignment(label, HPos.RIGHT);
    	GridPane.setValignment(label, VPos.BOTTOM);
    	label.setTextFill(Color.WHITE);
    	
    	
    	// Finalise the image, and add listeners to update when inv. changes
    	ImageView itemFinal = item;
    	
    	uses.addListener(new ChangeListener<Number>() {
    		@Override
    		public void changed(ObservableValue<? extends Number> observable,
                    Number oldValue, Number newValue) {
    			if (index == 0) {
    				itemFinal.setImage(swordImage);
    			}
    			
    			if (newValue.intValue() == 0) {
    				overlay.toFront();
    			} else {
    				overlay.toBack();
    			}
    			
    			label.toFront();
    			label.setText("x" + newValue.toString());
    		}
    	});
    	
    	// Weapons need a special case for when the player picks up a bow.
    	if (index == 0) {
    		IntegerProperty bowUses = p.getInventory().getObservableBow();
    		
    		bowUses.addListener(new ChangeListener<Number>() {
        		@Override
        		public void changed(ObservableValue<? extends Number> observable,
                        Number oldValue, Number newValue) {
        			itemFinal.setImage(bowImage);
        			
        			if (newValue.intValue() == 0) {
        				overlay.toFront();
        			} else {
        				overlay.toBack();
        			}
        			label.toFront();
        			label.setText("x" + newValue.toString());
        		}
        	});
    	}

    	invItems.add(itemFinal);
    	invItems.add(overlay);
    	invItems.add(label);
    }
    
    @Override
    public void loadInvItem(BooleanProperty uses, int index, Player p) {
    	// Boolean properties are specific to key
    	ImageView item = new ImageView(keyImage);
    	GridPane.setColumnIndex(item, index);
    	
    	ImageView overlay = new ImageView(invOverlayImage);
    	GridPane.setColumnIndex(overlay, index);
    	
    	uses.addListener(new ChangeListener<Boolean>() {
    		@Override
    		public void changed(ObservableValue<? extends Boolean> observable,
                    Boolean oldValue, Boolean newValue) {
    			// Colour-code the keys
    			switch(keyIds.indexOf(p.getInventory().getKeyId())) {
    	    	case 0:
    	    		item.setImage(keyImage);
    	    		break;
    	    	case 1:
    	    		item.setImage(blueKeyImage);
    	    		break;
    	    	case 2:
    	    		item.setImage(redKeyImage);
    	    		break;
    	    	}
    			
    			if (newValue.booleanValue()) {
    				overlay.toBack();
    			} else {
    				overlay.toFront();
    			}
    		}
    	});

    	invItems.add(item);
    	invItems.add(overlay);
    }

    // -----------------------------------------------
    // Adding/removing entities from controller loader
    // -----------------------------------------------
    
    private void addEntity(Entity entity, ImageView view) {
        trackPosition(entity, view);
        entities.add(view);
    }
    
    protected void spawnBomb(Bomb bomb) {
        ImageView view = new ImageView(bombImage);
        addEntity(bomb,view);
    }
    
    protected void spawnArrow(Arrow arrow) {
        ImageView view = new ImageView(arrowImage);
        addEntity(arrow,view);
    	prevController.addEntity(view);
    }
    
    protected void spawnGnome(Gnome gnome) {
        ImageView view = new ImageView(gnomeImage);
        addEntity(gnome,view);
    	prevController.addEntity(view);
    }
    
    // The opposite of adding an entity is removing them. We derender them in this way.
    protected void derender(Entity entity) {
    	//We know an entity we want to remove, based on location & type.
    	// However we also need to check that we are removing the right entity.
    	// We do this by checking the image matches the type of entity we want to derender.
    	for (ImageView v : entities) {
    		if (entity.getX()==GridPane.getColumnIndex(v) &&
     			entity.getY()==GridPane.getRowIndex(v)) {
    			
	    		if (swordImage.equals(v.getImage()) && entity instanceof Sword)
	    			prevController.removeEntity(v);
	    		else if (enemyImage.equals(v.getImage()) && entity instanceof Enemy)
	    			prevController.removeEntity(v);
	    		else if (houndImage.equals(v.getImage()) && entity instanceof Hound)
    				prevController.removeEntity(v);
	    		else if(gnomeImage.equals(v.getImage()) && entity instanceof Gnome)
    				prevController.removeEntity(v);
	    		else if ((bombImage.equals(v.getImage()) ||
    				      bombFuseSequence.get(0).equals(v.getImage())) &&
    				     entity instanceof Bomb) {
    				prevController.removeEntity(v);
        		} else if (invincibilityImage.equals(v.getImage()) &&
        				   entity instanceof Invincibility) {
    				prevController.removeEntity(v);
        		} else if (confusionImage.equals(v.getImage()) &&
        				   entity instanceof Confusion) {
        			prevController.removeEntity(v);
        		} else if(treasureImage.equals(v.getImage()) && entity instanceof Treasure)
        			prevController.removeEntity(v);
        		else if(treasureImage.equals(v.getImage()) &&
        				entity instanceof TrappedTreasure) {
	    			prevController.removeEntity(v);
        		} else if((wallImage.equals(v.getImage()) ||
        				   mossyWallImage.equals(v.getImage()) ||
        				   webWallImage.equals(v.getImage())) &&
        				  entity instanceof Wall) {
        			prevController.removeEntity(v);
        		} else if((keyImage.equals(v.getImage()) ||
        				   blueKeyImage.equals(v.getImage()) ||
        				   redKeyImage.equals(v.getImage())) &&
        				  entity instanceof Key) {
        			prevController.removeEntity(v);
        		} else if(bowImage.equals(v.getImage()) && entity instanceof Bow)
        			prevController.removeEntity(v);
        		else if(arrowImage.equals(v.getImage()) && entity instanceof Arrow)
	    			prevController.removeEntity(v);
        		else if ((trollStanding.equals(v.getImage()) ||
    					  trollRaises.contains(v.getImage()) ||
    					  trollAttacks.contains(v.getImage())) &&
    				     entity instanceof Troll) {
	    			prevController.removeEntity(v);
        		}
    		}
		}
    }
    
    // -----------------------
    // Custom Listeners for UI
    // -----------------------

    /**
     * Set a node in a GridPane to have its position track the position of an
     * entity in the dungeon.
     *
     * By connecting the model with the view in this way, the model requires no
     * knowledge of the view and changes to the position of entities in the
     * model will automatically be reflected in the view.
     * @param entity
     * @param node
     */
    private void trackPosition(Entity entity, Node node) {
        GridPane.setColumnIndex(node, entity.getX());
        GridPane.setRowIndex(node, entity.getY());
        entity.x().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable,
                    Number oldValue, Number newValue) {
            	if (newValue.intValue() >= 0) { // This check is here so we can move things to -1,-1 when they are removed.
                    GridPane.setColumnIndex(node, newValue.intValue());
            	}
            }
        });
        entity.y().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable,
                    Number oldValue, Number newValue) {
            	if (newValue.intValue() >= 0) { // This check is here so we can move things to -1,-1 when they are removed.
            		GridPane.setRowIndex(node, newValue.intValue());
            	}
            }
        });
    }
    
    //Ensure texture of bomb updated with the fuse timer
    private void trackFuse(Bomb litBomb, ImageView node) {
    	litBomb.timer().addListener(new ChangeListener<Number>() {
    		@Override
    		public void changed(ObservableValue<? extends Number> observable,
                    Number oldValue, Number newValue) {
    			if (newValue.intValue() >= 0 && newValue.intValue() < 4) {
        			node.setImage(bombFuseSequence.get(newValue.intValue()));
    			}
    		}
    	});
    }
    
    //Ensure door texture tracks if it is opened.
    private void trackOpened(LockedDoor door, ImageView node) {
    	door.locked().addListener(new ChangeListener<Boolean>() {
    		@Override
    		public void changed(ObservableValue<? extends Boolean> observable,
                    Boolean oldValue, Boolean newValue) {
    			if (!newValue.booleanValue()) {
    				node.setImage(openDoorImage);
    			}
    			// Doors are never closed once opened
    		}
    	});
    }
    
    // Ensure troll texture matches its movements
    private void trackTroll(Troll troll, ImageView node) {
    	// Track raising of club to the correct textures
    	troll.getObservableRaising().addListener(new ChangeListener<Boolean>() {
    		@Override
    		public void changed(ObservableValue<? extends Boolean> observable,
                    Boolean oldValue, Boolean newValue) {
    			if (newValue.booleanValue()) {
    				switch(troll.getFacing()) {
					case UP:
						node.setImage(trollRaises.get(0));
						break;
					case DOWN:
						node.setImage(trollRaises.get(1));
						break;
					case LEFT:
						node.setImage(trollRaises.get(2));
						break;
					case RIGHT:
						node.setImage(trollRaises.get(3));
						break;
					case NONE:
						node.setImage(trollStanding);
						break;
    				}
    			}
    			// If the troll stops raising, it must start attacking.
    			// No need to change back to troll standing texture.
    		}
    	});
    	
    	// Track attacking with club to correct textures
    	troll.getObservableAttacking().addListener(new ChangeListener<Boolean>() {
    		@Override
    		public void changed(ObservableValue<? extends Boolean> observable,
                    Boolean oldValue, Boolean newValue) {
    			if (newValue.booleanValue()) {
    				switch(troll.getFacing()) {
					case UP:
						node.setImage(trollAttacks.get(0));
						break;
					case DOWN:
						node.setImage(trollAttacks.get(1));
						break;
					case LEFT:
						node.setImage(trollAttacks.get(2));
						break;
					case RIGHT:
						node.setImage(trollAttacks.get(3));
						break;
					case NONE:
						node.setImage(trollStanding);
						break;
    				}
    			} else {
    				// Return to default stance
    				node.setImage(trollStanding);
    			}
    		}
    	});
    }
    
    // --------------------------
    // Loading or reloading of UI
    // --------------------------
    
    // Reloads the current entities, only for this class.
    protected void reRenderLevel() {
    	this.entities = new ArrayList<>();
    	this.invItems = new ArrayList<>();
        keyIds = new ArrayList<>();
    	
    	this.reloadCurr();
    }
    
    // Destroys last stage, creates new one and renders it.
    @Override
    public void refreshDungeon() {
    	
    	try {
    		if (prevController != null) {
        		prevController.getLastStage().close();
    		}
	        
	    	Stage stage = new Stage();
	    	stage.setTitle("Dungeon");
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("DungeonView.fxml"));

	    	reRenderLevel();
	    	DungeonController controller = this.loadController();

	        loader.setController(controller);
	        Parent root = loader.load();
	        Scene scene = new Scene(root);
	        root.requestFocus();
	        stage.setScene(scene);
	        stage.show();
    	}
    	catch (IOException e) {
    		e.printStackTrace();
    	}
    	
	}

    /**
     * Create a controller that can be attached to the DungeonView with all the
     * loaded entities.
     * @return
     * @throws FileNotFoundException
     */
    public DungeonController loadController() throws FileNotFoundException {
    	loadLevel();
    	prevController = new DungeonController(this.getCurrDungeon(), entities, invItems);
        return prevController;
    }
}
