/**
 *
 */
package unsw.dungeon;

import java.util.ArrayList;
import java.util.List;
import java.util.Observer;

import entities.*;
import entities.enemies.Gnome;
import entities.items.Arrow;
import entities.items.Bomb;
import goals.Goal;
import javafx.application.Platform;

/**
 * A dungeon in the interactive dungeon player.
 *
 * A dungeon can contain many entities, each occupy a square. More than one
 * entity can occupy the same square.
 *
 * @author Robert Clifton-Everest
 * Modified by Ian/Tyson
 */
public class Dungeon {
    private int width, height;
    private List<Entity> entities;
    private Player player;
    private Goal goal;
    
    private DungeonLoader loader;
    private boolean completed = false;
    

    public Dungeon(DungeonLoader loader, int width, int height) {
        this.width = width;
        this.height = height;
        this.entities = new ArrayList<>();
        this.player = null;
        this.goal = null;
        this.loader = loader;
    }
    
    public Goal getGoal() {
        return goal;
    }
    
    public void setGoal(Goal s) {
        goal = s;
    }
    
    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public Player getPlayer() {
        return player;
    }
    
    public void bombLoad(Bomb b) {
    	if (loader != null)
    		loader.onLoad(b);
    }

    public void setPlayer(Player player) {
        this.player = player;
        
        for (Entity e: this.entities) {
        	if (e != null && e.observesPlayer()) {
        		e.observePlayer(player);
        	}
        }
    }

    public void addEntity(Entity entity) {
        entities.add(entity);
    }
    
    // For adding entities that need no special visual things
    //  while the dungeon is running.
    public void spawnArrow(Arrow arrow) {
    	if (loader != null)
    		loader.spawnArrow(arrow);
    	entities.add(arrow);
    }
    
    public void spawnGnome(Gnome gnome) {
    	if (loader != null)
    		loader.spawnGnome(gnome);
    	entities.add(gnome);
    }
    
    public void removeEntity(Entity entity) {
    	//Remove it from the entity list
    	entities.remove(entity);
    	//De render it
    	if (loader != null) {
        	loader.derender(entity);
    	}
    	
    	if (entity instanceof Observer) {
        	player.deleteObserver((Observer) entity);
    	}
    }
    
    public List<Entity> getTileEntities(int x, int y) {
    	List<Entity> result = new ArrayList<Entity>();
    	
    	for (Entity e: this.entities) {
    		if (e != null && e.getX() == x && e.getY() == y) {
    			result.add(e);
    		}
    	}
    	
    	return result;
    }
    
    public List<Entity> getAllEntitiesOfType(Entity exampleObject) {
    	List<Entity> result = new ArrayList<Entity>();
    	
    	for (Entity e: this.entities) {
    		if (e != null && e.getClass() == exampleObject.getClass()) {
    			result.add(e);
    		}
    	}
    	
    	return result;
    }
    
    public void notifyGoalIncomplete(String goal) {
    	this.goal.notifyGoalIncomplete(goal);
    }
    
    public void notifyGoal(String goal) {
    	if (this.goal != null) {
    		this.goal.notifyGoal(goal);
    		
        	if (!completed && this.goal.getCompleted() && loader != null) {
        		completed = true;
        		
        		// Need to delay so scene is properly updated before message displayed
        		new Thread(() -> {
    		       try {
    		          Thread.sleep(100);
    		       } catch (InterruptedException e) {
    		          e.printStackTrace();
    		       }
    		       
    		       Platform.runLater(() -> loader.handleCompletedLevel("You "+this.goal.getMessage()+"! You win!"));
        		}).start();
        		
        	}
    	}
    }
    
    // Stub for notifying when you die
    public void notifyDeath() {
    	if (loader != null) {
			// Need to delay so scene is properly updated before message displayed
	    	new Thread(() -> {
			       try {
			          Thread.sleep(100);
			       } catch (InterruptedException e) {
			          e.printStackTrace();
			       }
			       
			       Platform.runLater(() -> loader.handleDeath("You died."));
	 		}).start();
    	}
    }
    
    public void restartLevel() {
    	loader.loadLevel();
    	loader.refreshDungeon();
    }
}
