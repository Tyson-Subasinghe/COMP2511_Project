package unsw.dungeon;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class DungeonApplication extends Application {

    @Override
    public void start(Stage primaryStage) throws IOException {
        primaryStage.setTitle("Dungeon");
        List<String> filenames = new ArrayList<String>();
        

        filenames.add("demo_keyColours.json");
        filenames.add("demo_dontMessUp.json");
        filenames.add("demo_spaceInvaders.json");
        filenames.add("demo_bossFight.json");
        
        // Testing levels:
        /*
        filenames.add("trollSandbox.json");
        filenames.add("sandbox.json");
        filenames.add("advancedWithEnemy.json");
        filenames.add("bowTest2.json");
        filenames.add("bowTest.json");
        filenames.add("simpleMazeOrBoulders.json");
        filenames.add("boulders.json");
        filenames.add("simpleMultiKeyTest.json");
        filenames.add("enemyPathfindTest.json");
        filenames.add("simpleMazeNBoulders.json");
        filenames.add("simpleSingleKeyTest.json");
        filenames.add("advanced.json");
        filenames.add("maze.json");
        */


        DungeonControllerLoader dungeonLoader = new DungeonControllerLoader(filenames);

        DungeonController controller = dungeonLoader.loadController();

        FXMLLoader loader = new FXMLLoader(getClass().getResource("DungeonView.fxml"));
        loader.setController(controller);
        Parent root = loader.load();
        Scene scene = new Scene(root);
        root.requestFocus();
        primaryStage.setScene(scene);
        primaryStage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }

}
