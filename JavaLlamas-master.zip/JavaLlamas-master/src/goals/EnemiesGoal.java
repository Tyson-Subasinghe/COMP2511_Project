package goals;

import java.util.List;
import entities.*;
import entities.enemies.Enemy;
import entities.enemies.Hound;
import entities.enemies.Troll;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import unsw.dungeon.Dungeon;

public class EnemiesGoal extends Goal{
	private boolean completed = false;
	private StringProperty message = new SimpleStringProperty("Enemies goal uninitialised");
	
	private int currCount = 0;
	private int totalCount = 0;
	
	public int getTotalCount() {
		return totalCount;
	}
	
	//Only needed if we do fancy extensions like spawn an enemy
	public void setTotalCount(int num) {
		totalCount = num;
	}
	
	public void initCounts(Dungeon dungeon) {
		List<Entity> enemyObjectives = dungeon.getAllEntitiesOfType(new Enemy(null,0,0));
		enemyObjectives.addAll(dungeon.getAllEntitiesOfType(new Hound(null,0,0)));
		enemyObjectives.addAll(dungeon.getAllEntitiesOfType(new Troll(null,0,0)));
		
	    totalCount = enemyObjectives.size();
	    
	    message.set(String.format("Kill all enemies (%d remaining).", totalCount - currCount));
	}
	
	public int getCurrCount() {
		return currCount;
	}
	
	public void setCompleted(boolean status) {
		completed=status;
	}
	
	public boolean getCompleted() {
		return this.completed;
	}
	
	@Override
	public String getGoalProgress() {
	    return message.get();
	}
	
	@Override
	public void notifyGoal(String goalTxt){
		if (goalTxt.equals("enemies")) {
			this.completed = true;
		}
	}
	
	
	@Override
	public void notifyGoalIncomplete(String goalTxt){
		if (goalTxt.equals("enemies")) {
			this.completed = false;
		}
	}
	
	@Override
	public String getMessage() {
	    return "defeated all the enemies";
	}
	
	public String getType() {
		return "enemies";
	}
	
	public int incCount(String goalTxt) {
		if (goalTxt.equals("enemies")) {
			currCount++;
			message.set(String.format("Kill all enemies (%d remaining).", totalCount - currCount));
		}
		
		return this.currCount;
	}
	
	public int decCount(String goalTxt) {
		if (goalTxt.equals("enemies")) {
			currCount--;
			message.set(String.format("Kill all enemies (%d remaining).", totalCount - currCount));
		}
		
		return this.currCount;
	}
	
	@Override
	public StringProperty getObservableProgress() {
		return message;
	}
}
