package goals;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import unsw.dungeon.Dungeon;

public class MazeGoal extends Goal {
	private boolean completed = false;
	private StringProperty message = new SimpleStringProperty("Find the exit.");
	
	public int getTotalCount() {
		return 0;
	}

	//Only needed if we do fancy extensions like spawn an enemy
	public void setTotalCount(int num) {}
	
	public void initCounts(Dungeon dungeon) {}
	
	public int getCurrCount() {
		return 0;
	}
	
	public void setCompleted(boolean status) {
		completed=status;
		
		if (completed) {
			this.message.set("Find the exit. (Complete)");
		} else {
			this.message.set("Find the exit.");
		}
	}
	
	public boolean getCompleted() {
		return this.completed;
	}
	
	@Override
	public String getGoalProgress() {
		return message.get();
	}
	
	@Override
	public void notifyGoal(String goalTxt){
		if (goalTxt.equals("exit")) {
			setCompleted(true);
		}
	}
	
	@Override
	public void notifyGoalIncomplete(String goalTxt){
		if (goalTxt.equals("exit")) {
			setCompleted(false);
		}
	}
	
	@Override
	public String getMessage() {
		return "found the exit to the maze";
	}
	
	
	public String getType() {
		return "exit";
	}
	
	public boolean isCompleted() { 
		return this.completed;
	}
	
	public int incCount(String goalTxt) {
		return 0;
	}
	
	public int decCount(String goalTxt) {
		return 0;
	}
	
	@Override
	public StringProperty getObservableProgress() {
		return message;
	}
}
