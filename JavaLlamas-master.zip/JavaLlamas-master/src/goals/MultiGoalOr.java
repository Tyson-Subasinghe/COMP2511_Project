package goals;

import java.util.List;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import unsw.dungeon.Dungeon;

public class MultiGoalOr extends Goal {
	List<Goal> subgoals;
	private StringProperty message = new SimpleStringProperty("Multi OR uninitialised");

	public MultiGoalOr(List<Goal> subgoals) {
		if (subgoals.size() == 0) {
			System.out.println("WARNING: OR Goal defined with no subgoals, will never be completed.");
		}
		
		this.subgoals = subgoals;
	}
	
	@Override
	public boolean getCompleted() {
		for (Goal g: subgoals) {
			if (g.getCompleted()) {
				return true;
			}
		}
		
		return false;
	}
	
	@Override
	public String getMessage() {
		for (Goal g: subgoals) {
			if (g.getCompleted()) {
				return g.getMessage();
			}
		}
		
		return "<Error: getMessage called when OR goal not complete>";
	}

	private void updateMessage() {
		String msg = "Complete any of the following:";
		
		for (Goal g: subgoals) {
			msg += "\n" + g.getGoalProgress();
		}
		
		message.set(msg.replace("\n", "\n\t"));
	}
	
	@Override
	public void notifyGoal(String goalTxt) {
		for (Goal g: subgoals) {
			g.notifyGoal(goalTxt);
		}
		
		updateMessage();
	}
	
	@Override
	public void initCounts(Dungeon d) {
		for (Goal g: subgoals) {
			g.initCounts(d);
		}
		
		updateMessage();
	}
	
	@Override
	public int incCount(String goalTxt) {
		for (Goal g: subgoals) {
			g.incCount(goalTxt);
		}
		
		updateMessage();
		
		return 0;
	}
	
	@Override
	public int decCount(String goalTxt) {
		for (Goal g: subgoals) {
			g.decCount(goalTxt);
		}
		
		updateMessage();
		
		return 0;
	}
	
	@Override
	public void notifyGoalIncomplete(String goalTxt) {
		for (Goal g: subgoals) {
			g.notifyGoalIncomplete(goalTxt);
		}
		
		updateMessage();
	}
	
	@Override
	public String getGoalProgress() {
		return message.get();
	}

	@Override
	public StringProperty getObservableProgress() {
		return message;
	}
}
