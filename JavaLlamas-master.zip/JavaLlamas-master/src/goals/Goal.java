package goals;

import javafx.beans.property.StringProperty;
import unsw.dungeon.Dungeon;

public abstract class Goal {
	public abstract boolean getCompleted();
	
	public abstract void notifyGoal(String goalText);
	public abstract void notifyGoalIncomplete(String goalText);
	
	public abstract String getMessage();
	
	public abstract String getGoalProgress();

	public abstract int incCount(String goalText);
	public abstract int decCount(String goalText);
	
	public abstract void initCounts(Dungeon dungeon);
	
	public abstract StringProperty getObservableProgress();
}
