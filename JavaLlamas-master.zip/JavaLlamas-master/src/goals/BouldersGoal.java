package goals;

import java.util.List;
import entities.*;
import entities.goalComponents.Switch;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import unsw.dungeon.Dungeon;

public class BouldersGoal extends Goal{
	private boolean completed = false;
	private StringProperty message = new SimpleStringProperty("Switch goal uninitialised");
	
	private int currCount = 0;
	private int totalCount = 0;
	
	public int getTotalCount() {
		return totalCount;
	}
	
	//Only needed if we do fancy extensions like spawn an enemy
	public void setTotalCount(int num) {
		totalCount = num;
	}
	
	public void initCounts(Dungeon dungeon) {
	    List<Entity> switchObjectives = dungeon.getAllEntitiesOfType(new Switch(null,0,0));
	    totalCount = switchObjectives.size();
	    
	    message.set(String.format("Trigger all switches (%d/%d).", currCount, totalCount));
	}
	
	public int getCurrCount() {
		return currCount;
	}
	
	public void setCompleted(boolean status) {
		completed=status;
	}
	
	public boolean getCompleted() {
		return this.completed;
	}
	
	@Override
	public String getGoalProgress() {
		return this.message.get();
	}
	
	@Override
	public void notifyGoal(String goalTxt){
		if (goalTxt.equals("boulders")) {
			this.completed = true;
		}
	}
	
	
	@Override
	public void notifyGoalIncomplete(String goalTxt){
		if (goalTxt.equals("boulders")) {
			this.completed = false;
		}
	}
	
	@Override
	public String getMessage() {
		return "triggered all the switches";
	}
	
	public String getType() {
		return "boulders";
	}
	
	public int incCount(String goalTxt) {
		if (goalTxt.equals("boulders")) {
			currCount++;
			message.set(String.format("Trigger all switches (%d/%d).", currCount, totalCount));
		}
		
		return this.currCount;
	}
	
	//decCount
	public int decCount(String goalTxt) {
		if (goalTxt.equals("boulders")) {
			currCount--;
			message.set(String.format("Trigger all switches (%d/%d).", currCount, totalCount));
		}
		
		return this.currCount;
	}
	
	@Override
	public StringProperty getObservableProgress() {
		return message;
	}
}
