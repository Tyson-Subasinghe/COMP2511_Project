package goals;

import java.util.List;
import entities.*;
import entities.enemies.TrappedTreasure;
import entities.goalComponents.Treasure;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import unsw.dungeon.Dungeon;

public class TreasureGoal extends Goal{
	private boolean completed = false;
	private StringProperty message = new SimpleStringProperty("Treasure goal uninitialised");

	private int currCount = 0;
	private int totalCount = 0;
	
	public int getTotalCount() {
		return totalCount;
	}

	//Only needed if we do fancy extensions like spawn an enemy
	public void setTotalCount(int num) {
		totalCount = num;
	}
	
	public void initCounts(Dungeon dungeon) {
    	List<Entity> treasureObjectives = dungeon.getAllEntitiesOfType(new Treasure(null,0,0));
    	treasureObjectives.addAll(dungeon.getAllEntitiesOfType(new TrappedTreasure(null,0,0)));
    	totalCount = treasureObjectives.size();
		
        this.message.set(String.format("Collect all the treasure (%d/%d).", currCount, totalCount));
	}
	
	public int getCurrCount() {
		return currCount;
	}
	
	public void setCompleted(boolean status) {
		completed=status;
		return;
	}
	
	public boolean getCompleted() {
		return this.completed;
	}
	
	@Override
	public String getGoalProgress() {
		return message.get();
	}
	
	@Override
	public void notifyGoal(String goalTxt){
		if (goalTxt.equals("treasure")) {
			this.completed = true;
		}
	}
	

	@Override
	public void notifyGoalIncomplete(String goalTxt){
		if (goalTxt.equals("treasure")) {
			this.completed = false;
		}
	}
	
	@Override
	public String getMessage() {
		return "found all the treasure";
	}
	
	public String getType() {
		return "treasure";
	}
	
	public int incCount(String goalTxt) {
		if (goalTxt.equals("treasure")) {
			currCount++;
			message.set(String.format("Collect all the treasure (%d/%d).", currCount, totalCount));
		}
		return this.currCount;
	}
	
	public int decCount(String goalTxt) {
		if (goalTxt.equals("treasure")) {
			currCount--;
			message.set(String.format("Collect all the treasure (%d/%d).", currCount, totalCount));
		}
		return this.currCount;
	}

	@Override
	public StringProperty getObservableProgress() {
		return message;
	}
}
