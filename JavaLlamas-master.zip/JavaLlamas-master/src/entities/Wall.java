package entities;
import unsw.dungeon.Dungeon;

public class Wall extends Entity {

    public Wall(Dungeon dungeon, int x, int y) {
        super(dungeon, x, y);
    }

    @Override
    public boolean isSolid() {
    	return true;
    }
}
