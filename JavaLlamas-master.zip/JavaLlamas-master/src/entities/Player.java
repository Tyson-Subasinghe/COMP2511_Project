package entities;

import java.util.List;
import unsw.dungeon.Dungeon;

import entities.enemies.Enemies;
import entities.items.Arrow;
import entities.items.Bomb;
import entities.items.Inventory;

import java.util.concurrent.ThreadLocalRandom;

/**
 * The player entity
 * @author Robert Clifton-Everest
 * Extended by Ian/Tyson
 */
public class Player extends Entity {

    private Dungeon dungeon;
    private Inventory inventory;

    /**
     * Create a player positioned in square (x,y)
     * @param x
     * @param y
     */
    public Player(Dungeon dungeon, int x, int y) {
        super(dungeon, x, y);
        this.dungeon = dungeon;
        this.inventory = new Inventory();
    }
    
    private void moveTo(int x, int y) {
    	boolean canMove = true;
    	
    	// Checking target is within the dungeon
    	if (x < 0 || x >= dungeon.getWidth()) canMove = false;
    	if (y < 0 || y >= dungeon.getHeight()) canMove = false;
    	
    	
    	// Checking if any entity in the target tile blocks movement
    	List<Entity> targetEntities = dungeon.getTileEntities(x, y);
    	
    	for (Entity e: targetEntities) {
    		canMove = canMove && (e.canMoveInto(this.getX(), this.getY()));
    	}
    	
    	if (canMove) {
    	
	    	// Updating all entities in the target tile that movement has occurred
	    	for (Entity e: targetEntities) {
	    		e.moveInto(this.getX(), this.getY());
	    	}
	    	
	    	this.y().set(y);
	    	this.x().set(x);
    	}
    	
    	passTime();
    	setChanged();
    	notifyObservers();
    }
    
    public void confusionMove() {
    	int random = ThreadLocalRandom.current().nextInt(1,5);
    	switch (random) {
    		case 1 :
	    		moveUp();
	    		break;
    		case 2 :
        		moveDown();
        		break;
    		case 3 :
        		moveLeft();
        		break;
    		case 4 :
        		moveRight();
        		break;
    	}
    	
    	return;
    }

    public void moveUp() {
    	moveTo(getX(), getY() - 1);
    }

    public void moveDown() {
    	moveTo(getX(), getY() + 1);
    }

    public void moveLeft() {
    	moveTo(getX() - 1, getY());
    }

    public void moveRight() {
    	moveTo(getX() + 1, getY());
    }
    
    private boolean isSpecialOrSolid(int x, int y) {
    	if (y < 0 || y >= dungeon.getHeight()) {
    		return true;
    	}
    	if (x < 0 || x >= dungeon.getWidth()) {
    		return false;
    	}
    	
    	List<Entity> entities = dungeon.getTileEntities(x, y);
    	
    	for (Entity e: entities) {
    		if (e.isSpecial() || e.isSolid()) {
    			return true;
    		}
    	}
    	
    	return false;
    }
    
    //Attack functions
    public void attackUp() {
    	if(this.getInventory().getSwordUses() > 0) {
    		attackTile(getX(), getY() - 1);
    	}
    	
    	if (this.getInventory().getBowUses() > 0) {
    		int currY = getY();
    		
    		// Fire the arrow, find where it hits
    		while (!isSpecialOrSolid(getX(), currY-1)) {
    			currY -= 1;
    		}
    		
    		attackTile(getX(), currY-1);
    		
    		dungeon.spawnArrow(new Arrow(dungeon, getX(), currY));
    		
    	}
    }

    public void attackDown() {
    	if(this.getInventory().getSwordUses() > 0) {
    		attackTile(getX(), getY() + 1);
    	}
    	
    	if (this.getInventory().getBowUses() > 0) {
    		int currY = getY();
    		
    		while (!isSpecialOrSolid(getX(), currY+1)) {
    			currY += 1;
    		}
    		
    		attackTile(getX(), currY+1);
    		
    		dungeon.spawnArrow(new Arrow(dungeon, getX(), currY));
    	}
    }

    public void attackLeft() {
    	if(this.getInventory().getSwordUses() > 0) {
    		attackTile(getX() - 1, getY());
    	}
    	
    	if (this.getInventory().getBowUses() > 0) {
    		int currX = getX();
    		
    		while (!isSpecialOrSolid(currX-1, getY())) {
    			currX -= 1;
    		}
    		
    		attackTile(currX-1, getY());
    		
    		dungeon.spawnArrow(new Arrow(dungeon, currX, getY()));
    	}
    }

    public void attackRight() {
    	if(this.getInventory().getSwordUses() > 0) {
    		attackTile(getX() + 1, getY());
    	}
    	
    	if (this.getInventory().getBowUses() > 0) {
    		int currX = getX();
    		
    		while (!isSpecialOrSolid(currX+1, getY())) {
    			currX += 1;
    		}
    		
    		attackTile(currX+1, getY());
    		
    		dungeon.spawnArrow(new Arrow(dungeon, currX, getY()));
    	}
    }
    
    
    private void attackTile(int x, int y) {
    	//Filter so you can't attack without a sword/bow
    	if(this.getInventory().getSwordUses() <=0 &&
    	   this.getInventory().getBowUses() <= 0) {
    		return;
    	}
    	
    	//Check for any enemies, and hurt them if they are there.
    	List<Entity> contents = dungeon.getTileEntities(x,y);
    	for (Entity e :contents) {
    		if (e instanceof Enemies) {
    			((Enemies) e).damage();
    		}
    	}
    	
    	if (this.getInventory().getSwordUses() > 0) {
    		this.getInventory().decSword();
    	}
    	if (this.getInventory().getBowUses() > 0) {
    		this.getInventory().decBow();
    	}
    	
    	passTime();
    	setChanged();
    	notifyObservers();
    }
    
    public void placeBomb(int x, int y) {
    	//When B is pressed, a LIT BOMB is spawned with 3 turns to detonation
    	
    	// No bombs in inventory, so nothing happens
    	if(this.getInventory().getBombUses() <= 0) {
    		return;
    	}
    	
    	
    	Bomb bomb = new Bomb(dungeon, x, y);
    	
    	bomb.setActive(true);
    	bomb.setTimer(4);
    	dungeon.bombLoad(bomb);
    	inventory.decBomb();
    	
    	dungeon.addEntity(bomb);
    	
    	passTime();
    	setChanged();
    	notifyObservers();
    }
    
    //PASSING OF TIME
    public void passTime() {
    	//Passes a turn, basically an ingame tick, for objects with length duration
    	if(inventory.getInvincibilityUses()>=1) {
    		inventory.decInvincibility();
    	}
    	
    	if (getInventory().getConfusionStatus())
    		getInventory().decConfusion();
    	
		if(getInventory().getConfusionUses()==0) {
			getInventory().setConfusionStatus(false);
		}
    }
    
    public Inventory getInventory() {
    	return inventory;
    }

	public boolean holdsKey(int id) {
		if (inventory.hasKey() && inventory.getKeyId() == id) {
			return true;
		}
		return false;
	}
	
	public boolean hasKey() {
		return inventory.hasKey();
	}
	
	public void takeKey() {
		inventory.takeKey();
	}
    	
}
