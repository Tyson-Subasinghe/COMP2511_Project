package entities.goalComponents;

import java.util.List;
import unsw.dungeon.Dungeon;
import java.util.Observable;
import java.util.Observer;

import entities.Entity;
import entities.Player;

public class Switch extends Entity implements Observer {
	private Dungeon dungeon;
	private boolean triggered;

    public Switch(Dungeon dungeon, int x, int y) {
        super(dungeon, x, y);
        triggered = false;
        this.dungeon = dungeon;
        
        if (dungeon != null && dungeon.getPlayer() != null) {
        	dungeon.getPlayer().addObserver(this);
        }
    }
    
    public boolean observesPlayer() {
    	return true;
    }
    
    public void observePlayer(Player p) {
    	p.addObserver(this);
    }
    
    public boolean getTriggered() {
    	return triggered;
    }
    
    @Override
    public void update(Observable o, Object args) {
    	List<Entity> onSwitch = dungeon.getTileEntities(this.getX(), this.getY());
    	for (Entity e: onSwitch) {
    		if (e instanceof Boulder) {
    			if (triggered == false) dungeon.getGoal().incCount("boulders");
    			triggered = true;
    			
    			boolean goalDone = true;
    			List<Entity> allSwitches = dungeon.getAllEntitiesOfType(this);
    			for (Entity eSwitch: allSwitches) {
    				Switch switchTile = (Switch) eSwitch;
    				goalDone = goalDone && switchTile.getTriggered();
    			}
    			
    			if (goalDone) {
        			dungeon.notifyGoal("boulders");
    			} else {
    				dungeon.notifyGoalIncomplete("boulders");
    			}
    			return;
    		}
    	}
    	
    	if (triggered == true) dungeon.getGoal().decCount("boulders");
    	triggered = false;
    }
}
