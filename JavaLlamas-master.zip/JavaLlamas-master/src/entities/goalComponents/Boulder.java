package entities.goalComponents;

import java.util.List;

import entities.Entity;
import unsw.dungeon.Dungeon;

public class Boulder extends Entity {
	private Dungeon dungeon;

    public Boulder(Dungeon dungeon, int x, int y) {
        super(dungeon, x, y);
        this.dungeon = dungeon;
    }
    
    public boolean isSpecial() {
    	return true;
    }
    
    public boolean canMoveInto(int oldPlayerX, int oldPlayerY) {
    	int nextX = 2*this.getX() - oldPlayerX;
    	int nextY = 2*this.getY() - oldPlayerY;
    	
    	if (nextX < 0 || nextX >= dungeon.getWidth() ||
    	    nextY < 0 || nextY >= dungeon.getHeight()) {
    		return false;
    	}
    	
    	List<Entity> nextTile = dungeon.getTileEntities(nextX, nextY);
    	
    	boolean canMove = true;
    	for (Entity tile: nextTile) {
    		// Need to check special first, because special tiles have more complicated
    		//  isSolid functions that we don't want to check.
    		if (tile.isSpecial() || tile.isSolid()) {
    			canMove = false;
    			break;
    		}
    	}
    	
    	return canMove;
    }
    
    public void moveInto(int oldPlayerX, int oldPlayerY) {
    	this.x().set(2*this.getX() - oldPlayerX);
    	this.y().set(2*this.getY() - oldPlayerY);
    }
}
