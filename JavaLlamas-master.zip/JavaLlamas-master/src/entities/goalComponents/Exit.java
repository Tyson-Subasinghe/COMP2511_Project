package entities.goalComponents;

import java.util.List;
import unsw.dungeon.Dungeon;
import java.util.Observable;
import java.util.Observer;

import entities.Entity;
import entities.Player;

public class Exit extends Entity implements Observer {
	private Dungeon dungeon;

    public Exit(Dungeon dungeon, int x, int y) {
        super(dungeon, x, y);
        this.dungeon = dungeon;
        
        if (dungeon != null && dungeon.getPlayer() != null) {
        	dungeon.getPlayer().addObserver(this);
        }
    }
    
    public boolean observesPlayer() {
    	return true;
    }
    
    public void observePlayer(Player p) {
    	p.addObserver(this);
    }
    
    @Override
    public void update(Observable o, Object args) {
    	if (o instanceof Player) {
    		Player p = (Player) o;
    		
    		if (p.getX() == this.getX() && p.getY() == this.getY()) {
    			dungeon.notifyGoal("exit");
    			return;
    		}
    		
    		List<Entity> pTile = dungeon.getTileEntities(p.getX(), p.getY());
    		
    		boolean offGoal = true;
    		for (Entity e: pTile) {
    			if (e instanceof Exit) {
    				offGoal = false;
    				break;
    			}
    		}
    		
    		if (offGoal) {
    			dungeon.notifyGoalIncomplete("exit");
    		}
    	}
    }
}
