package entities;

import java.util.Observable;
import unsw.dungeon.Dungeon;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

/**
 * An entity in the dungeon.
 * @author Robert Clifton-Everest
 * Extended by Ian/Tyson
 */
public class Entity extends Observable {

    // IntegerProperty is used so that changes to the entities position can be
    // externally observed.
    private IntegerProperty x, y;
    Dungeon dungeon;

    /**
     * Create an entity positioned in square (x,y)
     * @param x
     * @param y
     */
    public Entity(Dungeon dungeon, int x, int y) {
        this.x = new SimpleIntegerProperty(x);
        this.y = new SimpleIntegerProperty(y);
        this.dungeon = dungeon;
    }

    public IntegerProperty x() {
        return x;
    }

    public IntegerProperty y() {
        return y;
    }
    
    public int getY() {
        return y().get();
    }

    public int getX() {
        return x().get();
    }
    
    public boolean isSolid() {
    	return false;
    }
    
    public boolean isSpecial() {
    	return false;
    }
    
    public boolean canMoveInto(int oldPlayerX, int oldPlayerY) {
    	return !(this.isSolid());
    }
    
    public void moveInto(int oldPlayerX, int oldPlayerY) {
    	return;
    }
    
    public boolean observesPlayer() {
    	return false;
    }
    
    public void observePlayer(Player p) {
    	return;
    }
}
