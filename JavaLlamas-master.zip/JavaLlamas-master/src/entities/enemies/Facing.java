package entities.enemies;

public enum Facing {
	UP,
	DOWN,
	LEFT,
	RIGHT,
	NONE
}
