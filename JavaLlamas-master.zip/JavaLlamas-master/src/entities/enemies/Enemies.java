package entities.enemies;

import java.util.List;
import unsw.dungeon.Dungeon;
import java.util.Observable;
import java.util.Observer;

import entities.Entity;
import entities.Player;

public abstract class Enemies extends Entity implements Observer {
	private Dungeon dungeon;

    public Enemies(Dungeon dungeon, int x, int y) {
        super(dungeon, x, y);
        
        this.dungeon = dungeon;
    }
    
    public abstract boolean observesPlayer();
    
    public abstract void observePlayer(Player p);
    
    public abstract void setPathfinder(Pathfinder p);
    
    public abstract boolean isSpecial();
    
    @Override
    public abstract void update(Observable o, Object args);
    
    // Hurt the enemy
    public void damage() {
    	dungeon.removeEntity(this);
    	if (dungeon.getGoal() != null )
    		dungeon.getGoal().incCount("enemies");
		
		List<Entity> enemies = dungeon.getAllEntitiesOfType(new Enemy(null, 0, 0 ));
		enemies.addAll(dungeon.getAllEntitiesOfType(new Hound(null, 0, 0 )));
		enemies.addAll(dungeon.getAllEntitiesOfType(new Troll(null, 0, 0 )));
		
		if (enemies.size() == 0) {
			dungeon.notifyGoal("enemies");
		}
    }
}
