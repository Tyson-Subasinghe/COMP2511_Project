package entities.enemies;

import java.util.List;
import unsw.dungeon.Dungeon;
import java.util.Observable;
import java.util.Observer;

import entities.Entity;
import entities.Player;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;

public class Troll extends Enemies implements Observer {
	private Dungeon dungeon;
	private Pathfinder pathfinder;
	private Facing facing;
	private BooleanProperty attacking;
	private BooleanProperty raising;
	private int skipTurn;
	private int hp;

    public Troll(Dungeon dungeon, int x, int y) {
        super(dungeon, x, y);
        this.dungeon = dungeon;
        
        if (dungeon != null && dungeon.getPlayer() != null) {
        	dungeon.getPlayer().addObserver(this);
        }
        
        pathfinder = new PathfindTowards();
        facing = Facing.NONE;

        attacking = new SimpleBooleanProperty(false);
        raising = new SimpleBooleanProperty(false);
        skipTurn = 1;
        
        hp = 3;
    }
    
    public Facing getFacing() {
    	return facing;
    }
    
    public BooleanProperty getObservableAttacking() {
    	return attacking;
    }
    
    public BooleanProperty getObservableRaising() {
    	return raising;
    }
    
    @Override
    public void damage() {
    	hp -= 1;
    	
    	if (hp == 0) {
        	dungeon.removeEntity(this);
        	if (dungeon.getGoal() != null)
        		dungeon.getGoal().incCount("enemies");
    		
    		List<Entity> enemies = dungeon.getAllEntitiesOfType(new Enemy(null, 0, 0 ));
    		enemies.addAll(dungeon.getAllEntitiesOfType(new Troll(null, 0, 0 )));
    		enemies.addAll(dungeon.getAllEntitiesOfType(new Hound(null, 0, 0 )));
    		
    		if (enemies.size() == 0) {
    			dungeon.notifyGoal("enemies");
    		}
    	}
    }
    
    public boolean observesPlayer() {
    	return true;
    }
    
    public void observePlayer(Player p) {
    	p.addObserver(this);
    }
    
    public void setPathfinder(Pathfinder p) {
    	pathfinder = p;
    }
    
    public boolean isSpecial() {
    	return true;
    }
    
    @Override
    public void update(Observable o, Object args) {
    	if (o instanceof Player) {
    		Player p = (Player) o;
    		
    		if (p.getInventory().getInvincibilityUses() > 0) {
    			setPathfinder(new PathfindAway());
    		}else {
    			setPathfinder(new PathfindTowards());
    		}
    		
			int targetX = pathfinder.nextX(dungeon, this.getX(), this.getY(), p.getX(), p.getY());
			int targetY = pathfinder.nextY(dungeon, this.getX(), this.getY(), p.getX(), p.getY());
	    	
	    	if (raising.get()) {
	    		targetX = getX();
	    		targetY = getY();
	    		
	    		switch (facing) {
	    		case UP:
	    			targetY -= 1;
	    			break;
	    		case DOWN:
	    			targetY += 1;
	    			break;
	    		case LEFT:
	    			targetX -= 1;
	    			break;
	    		case RIGHT:
	    			targetX += 1;
	    			break;
	    		case NONE:
	    			break;
	    		}
	    	}
	    	
	    	
			if (targetX <= 0)
    			targetX = 0;
    		if (targetX >= dungeon.getWidth())
    			targetX = dungeon.getWidth() - 1;
    		if (targetY <= 0)
    			targetY = 0;
    		if (targetY >= dungeon.getHeight())
    			targetY = dungeon.getHeight() - 1;
			
			List<Entity> targetEntities = dungeon.getTileEntities(targetX, targetY);
			boolean canMove = true;
	    	for (Entity tile: targetEntities) {
	    		// Need to check special first, because special tiles have more complicated
	    		//  isSolid functions that we don't want to check.
	    		if (tile.isSpecial() || tile.isSolid()) {
	    			canMove = false;
	    			break;
	    		}
	    	}
	    	
	    	if (attacking.get()) {
	    		attacking.set(false);
	    		skipTurn = 2;
	    	}
	    	
	    	
	    	if (canMove && skipTurn == 0) {
	    		if (raising.get()) {
	    			raising.set(false);
	    			attacking.set(true);
	    		} else {
	    			skipTurn += 1;
	    		}
	    		
	    		this.x().set(targetX);
	    		this.y().set(targetY);
	    	} else if (skipTurn >= 1){
	    		skipTurn -= 1;
	    	}

	    	int extraAttackX = -1;
	    	int extraAttackY = -1;
	    	
	    	if (attacking.get()) {
	    		extraAttackX = getX();
	    		extraAttackY = getY();
	    		
	    		switch (facing) {
	    		case UP:
	    			extraAttackY -= 1;
	    			break;
	    		case DOWN:
	    			extraAttackY += 1;
	    			break;
	    		case LEFT:
	    			extraAttackX -= 1;
	    			break;
	    		case RIGHT:
	    			extraAttackX += 1;
	    			break;
	    		case NONE:
	    			break;
	    		}
	    	}
	    	
    		if ((p.getX() == this.getX() && p.getY() == this.getY()) ||
    			(attacking.get() && p.getX() == extraAttackX && p.getY() == extraAttackY)){
    			if(p.getInventory().getInvincibilityUses()<=0) {
    				dungeon.notifyDeath();
    			}else {
    				if (dungeon.getGoal() != null) {
        				dungeon.getGoal().incCount("enemies");
    				}
    				dungeon.removeEntity(this);
    				
    				List<Entity> enemies = dungeon.getAllEntitiesOfType(new Enemy(null, 0, 0 ));
    	    		enemies.addAll(dungeon.getAllEntitiesOfType(new Troll(null, 0, 0 )));
    	    		enemies.addAll(dungeon.getAllEntitiesOfType(new Hound(null, 0, 0 )));
    	    		
    	    		if (enemies.size() == 0) {
    	    			dungeon.notifyGoal("enemies");
    	    		}
    			}
    		}
    		
    		if (!raising.get() && !attacking.get() &&
    			p.getInventory().getInvincibilityUses() == 0 &&
    			Math.abs(p.getX() - getX()) + Math.abs(p.getY() - getY()) == 1) {
    			
    			facing = Facing.NONE;
    			if (p.getX() == getX() && p.getY() < getY()) facing = Facing.UP;
    			if (p.getX() == getX() && p.getY() > getY()) facing = Facing.DOWN;
    			if (p.getX() < getX() && p.getY() == getY()) facing = Facing.LEFT;
    			if (p.getX() > getX() && p.getY() == getY()) facing = Facing.RIGHT;
    			
    			raising.set(true);
    			
    			skipTurn = 0;
    		}
    	}
    }
}
