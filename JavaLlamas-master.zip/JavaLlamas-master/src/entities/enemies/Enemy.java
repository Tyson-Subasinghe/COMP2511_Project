package entities.enemies;

import java.util.List;
import unsw.dungeon.Dungeon;
import java.util.Observable;
import java.util.Observer;

import entities.Entity;
import entities.Player;

public class Enemy extends Enemies implements Observer {
	private Dungeon dungeon;
	private Pathfinder pathfinder;

    public Enemy(Dungeon dungeon, int x, int y) {
        super(dungeon, x, y);
        this.dungeon = dungeon;
        
        if (dungeon != null && dungeon.getPlayer() != null) {
        	dungeon.getPlayer().addObserver(this);
        }
        
        pathfinder = new PathfindTowards();
        
    }
    
    public boolean observesPlayer() {
    	return true;
    }
    
    public void observePlayer(Player p) {
    	p.addObserver(this);
    }
    
    public void setPathfinder(Pathfinder p) {
    	pathfinder = p;
    }
    
    public boolean isSpecial() {
    	return true;
    }
    
    @Override
    public void update(Observable o, Object args) {
    	if (o instanceof Player) {
    		Player p = (Player) o;
    		
    		if (p.getInventory().getInvincibilityUses() > 0) {
    			setPathfinder(new PathfindAway());
    		}else {
    			setPathfinder(new PathfindTowards());
    		}
    		
			int targetX = pathfinder.nextX(dungeon, this.getX(), this.getY(),
										   p.getX(), p.getY());
			int targetY = pathfinder.nextY(dungeon, this.getX(), this.getY(),
									       p.getX(), p.getY());
			
			if (targetX <= 0)
    			targetX = 0;
    		if (targetX >= dungeon.getWidth())
    			targetX = dungeon.getWidth() - 1;
    		if (targetY <= 0)
    			targetY = 0;
    		if (targetY >= dungeon.getHeight())
    			targetY = dungeon.getHeight() - 1;
			
			List<Entity> targetEntities = dungeon.getTileEntities(targetX, targetY);
			boolean canMove = true;
	    	for (Entity tile: targetEntities) {
	    		// Need to check special first, because special tiles have more complicated
	    		//  isSolid functions that we don't want to check.
	    		if (tile.isSpecial() || tile.isSolid()) {
	    			canMove = false;
	    			break;
	    		}
	    	}
	    	
	    	if (canMove) {
	    		this.x().set(targetX);
	    		this.y().set(targetY);
	    	}
	    	
    		if (p.getX() == this.getX() && p.getY() == this.getY()) {
    			if(p.getInventory().getInvincibilityUses()<=0) {
    				dungeon.notifyDeath();
    			}else {
    				damage();
    			}
    		}
    	}
    }
}
