package entities.enemies;

import java.util.List;
import unsw.dungeon.Dungeon;
import java.util.Observable;
import java.util.Observer;

import entities.Entity;
import entities.Player;
import entities.goalComponents.Treasure;

public class TrappedTreasure extends Entity implements Observer {
	private Dungeon dungeon;
	private int treasureCount;

    public TrappedTreasure(Dungeon dungeon, int x, int y) {
        super(dungeon, x, y);
        this.dungeon = dungeon;

        if (dungeon != null && dungeon.getPlayer() != null) {
        	dungeon.getPlayer().addObserver(this);
        }
    }
    
    
    
    public boolean observesPlayer() {
    	return true;
    }
    
    public void observePlayer(Player p) {
    	p.addObserver(this);
    }
    
    private boolean isSolid(int x, int y) {
    	List<Entity> entities = dungeon.getTileEntities(x, y);
    	
    	for (Entity e: entities) {
    		if (e.isSpecial() || e.isSolid()) {
    			return true;
    		}
    	}
    	
    	return false;
    }
    
    @Override
    public void update(Observable o, Object args) {
    	if (o instanceof Player) {
    		Player p = (Player) o;
    		if (p.getX() == this.getX() && p.getY() == this.getY()) {
    			
    			
    			//System.out.println("You've been GNOMED");
    			
    			//Spawn Gnome
    			if (!isSolid(p.getX()+1,p.getY())) {
    				dungeon.spawnGnome(new Gnome(dungeon, p.getX()+1, p.getY()));
    			} else if (!isSolid(p.getX()-1,p.getY())) {
    				dungeon.spawnGnome(new Gnome(dungeon, p.getX()-1, p.getY()));
    			} else if (!isSolid(p.getX(),p.getY()+1)) {
    				dungeon.spawnGnome(new Gnome(dungeon, p.getX(), p.getY()+1));
    			} else if (!isSolid(p.getX(),p.getY()-1)) {
    				dungeon.spawnGnome(new Gnome(dungeon, p.getX(), p.getY()-1));
    			}
				
    			dungeon.removeEntity(this);
    			//Add treasure counter
    			p.getInventory().addTreasure();
    			
    			boolean goalDone = false;
    			
    			if (dungeon.getGoal() != null)
    				dungeon.getGoal().incCount("treasure");
    			
    			//Count remaining treasure on the floor
    			List<Entity> treasureObjectives = dungeon.getAllEntitiesOfType(new Treasure(null,0,0));
    			treasureObjectives.addAll(dungeon.getAllEntitiesOfType(new TrappedTreasure(null,0,0)));
	            treasureCount = treasureObjectives.size();
	            
	            //If inventory + floor = inventory then 0 on floor therefore goal is done
	            //Simplify this to if none left on floor, we win
    			if(treasureCount==0) {
    				goalDone = true;
    			}
    			
    			
    			if (goalDone) {
        			dungeon.notifyGoal("treasure");
    			} else {
    				dungeon.notifyGoalIncomplete("treasure");
    			}
    		}
    	}
    }
}
