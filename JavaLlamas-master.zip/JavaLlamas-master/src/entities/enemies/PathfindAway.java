package entities.enemies;

import java.util.List;
import entities.*;
import unsw.dungeon.Dungeon;

public class PathfindAway implements Pathfinder {

	private boolean isSolid(Dungeon dungeon, int x, int y) {
		List<Entity> targetEntities = dungeon.getTileEntities(x, y);
		boolean canMove = true;
    	for (Entity tile: targetEntities) {
    		// Need to check special first, because special tiles have more complicated isSolid functions
    		//  that we don't want to check.
    		if (tile.isSpecial() || tile.isSolid()) {
    			canMove = false;
    			break;
    		}
    	}
    	
    	return !canMove;
	}

	@Override
	public int nextX(Dungeon dungeon, int currX, int currY, int targetX, int targetY) {
		if (Math.abs(currX - targetX) >= Math.abs(currY - targetY)) {
			if (currX == targetX) {
				return currX;
			}
			
			int moveX = currX - (targetX - currX)/(Math.abs(currX - targetX));
			
			boolean canMove = !isSolid(dungeon, moveX, currY);
	    	
			if (!canMove) {
				return currX;
			}
			
			return moveX;
		}
		
		// Dodge solid things in the y direction.
		if (Math.abs(currX - targetX) < Math.abs(currY - targetY)) {
			if (currY == targetY) {
				return currX;
			}
			int moveY = currY - (targetY - currY)/(Math.abs(currY - targetY));

			boolean canMove = !isSolid(dungeon, currX, moveY);
			
			if (!canMove) {
				if (currX == targetX) {
					return currX;
				}
				return currX - (targetX - currX)/(Math.abs(currX - targetX));
			}
		}
		
		return currX;
	}

	@Override
	public int nextY(Dungeon dungeon, int currX, int currY, int targetX, int targetY) {
		if (Math.abs(currX - targetX) < Math.abs(currY - targetY)) {
			if (currY == targetY) {
				return currY;
			}
			
			int moveY = currY - (targetY - currY)/(Math.abs(currY - targetY));
			
			boolean canMove = !isSolid(dungeon, currX, moveY);
	    	
			if (!canMove) {
				return currY;
			}
			
			return moveY;
		}

		// Dodge solid things in the x direction.
		if (Math.abs(currX - targetX) >= Math.abs(currY - targetY)) {
			if (currX == targetX) {
				return currY;
			}
			int moveX = currX - (targetX - currX)/(Math.abs(currX - targetX));

			boolean canMove = !isSolid(dungeon, moveX, currY);
	    	
			if (!canMove) {
				if (currY == targetY) {
					return currY;
				}
				return currY - (targetY - currY)/(Math.abs(currY - targetY));
			}
		}
		
		return currY;
	}

}
