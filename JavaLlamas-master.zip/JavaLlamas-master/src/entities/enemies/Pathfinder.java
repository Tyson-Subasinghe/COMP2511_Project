package entities.enemies;

import unsw.dungeon.Dungeon;

public interface Pathfinder {
	public abstract int nextX(Dungeon dungeon, int currX, int currY, int targetX, int targetY);
	public abstract int nextY(Dungeon dungeon, int currX, int currY, int targetX, int targetY);
}
