package entities.items;

import java.util.Observable;
import unsw.dungeon.Dungeon;
import java.util.Observer;

import entities.Entity;
import entities.Player;

public class Key extends Entity  implements Observer {
	private Dungeon dungeon;
	
	private int id;

    public Key(Dungeon dungeon, int x, int y, int id) {
        super(dungeon, x, y);
        this.dungeon = dungeon;
        
        this.id = id;
        
        if (dungeon != null && dungeon.getPlayer() != null) {
        	dungeon.getPlayer().addObserver(this);
        }
    }
    
    public boolean observesPlayer() {
    	return true;
    }
    
    public void observePlayer(Player p) {
    	p.addObserver(this);
    }
    
    public int getId() {
    	return id;
    }
    
    @Override
    public void update(Observable o, Object args) {
    	if (o instanceof Player) {
    		Player p = (Player) o;
    		
    		if (p.getX() == this.getX() && p.getY() == this.getY() && !p.hasKey()) {
    			dungeon.removeEntity(this);
    			//Add key to inventory
    			p.getInventory().addKey(id);
    		}
    	}
    }
}
