package entities.items;

import entities.Player;
import entities.goalComponents.Exit;
import javafx.beans.property.BooleanProperty;
import unsw.dungeon.Dungeon;
import javafx.beans.property.SimpleBooleanProperty;

public class LockedDoor extends Exit {
	private Dungeon dungeon;
	private int id;
	private BooleanProperty locked;

    public LockedDoor(Dungeon dungeon, int x, int y, int id) {
        super(dungeon, x, y);
        this.dungeon = dungeon;
        
        this.id = id;
        this.locked = new SimpleBooleanProperty(true);
    }
    
    public boolean isSpecial() {
    	return true;
    }
    
    public int getId() {
    	return id;
    }
    
    public boolean canMoveInto(int oldPlayerX, int oldPlayerY) {
    	if (!locked.getValue()) {
    		return true;
    	}
    	
    	Player p = dungeon.getPlayer();
    	if (p.holdsKey(id)) {
    		return true;
    	}
    	
    	return false;
    }
    
    public void moveInto(int oldPlayerX, int oldPlayerY) {
    	Player p = dungeon.getPlayer();
    	
    	if (locked.getValue())
    		p.takeKey();
    	
    	this.locked.set(false);
    }
    
    public BooleanProperty locked() {
    	return locked;
    }
}
