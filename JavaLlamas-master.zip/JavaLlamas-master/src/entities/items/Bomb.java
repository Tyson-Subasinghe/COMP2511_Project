package entities.items;

import java.util.List;
import java.util.Observable;
import java.util.Observer;

import entities.Entity;
import entities.Player;
import entities.Wall;
import entities.enemies.Enemy;
import entities.enemies.Gnome;
import entities.enemies.Hound;
import entities.enemies.Troll;
import unsw.dungeon.Dungeon;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class Bomb extends Entity implements Observer {
	private Dungeon dungeon;
	private boolean active = false;
	private IntegerProperty timer;

    public Bomb(Dungeon dungeon, int x, int y) {
        super(dungeon, x, y);
        this.dungeon = dungeon;
        
        if (dungeon != null && dungeon.getPlayer() != null) {
        	dungeon.getPlayer().addObserver(this);
        }
        
        this.timer = new SimpleIntegerProperty(0);
    }
    
    public boolean observesPlayer() {
    	return true;
    }
    
    public void observePlayer(Player p) {
    	p.addObserver(this);
    }
    
    public boolean getActive() {
    	return active;
    }
    
    public void setActive(boolean state) {
    	active=state;
    }
    
    public IntegerProperty timer() {
    	return timer;
    }
    
    public int getTimer() {
    	return timer.get();
    }
    
    public void setTimer(int num) {
    	timer.set(num);
    }
    
    public void decTimer() {
    	timer.set(timer.get() - 1);
    	
    	if(timer.get() == 0) {
    		detonate();
    	}
    	
    	if(timer.get() < 0) {
    		delete();
    	}
    }
    
    private void detonate() {
    	//Player is killed by bombs
    	Player p = dungeon.getPlayer();

    	if ((Math.abs(p.getX() - this.getX()) <= 1 && p.getY() == this.getY()) ||
    		(Math.abs(p.getY() - this.getY()) <= 1 && p.getX() == this.getX())) {
    		if (p.getInventory().getInvincibilityUses() <= 0) {
    			dungeon.notifyDeath();
    		}
    	}
    	
    	// Enemy destruction
    	List<Entity> enemies = dungeon.getAllEntitiesOfType(new Enemy(null, 0, 0));
    	enemies.addAll(dungeon.getAllEntitiesOfType(new Hound(null, 0, 0)));
    	enemies.addAll(dungeon.getAllEntitiesOfType(new Gnome(null, 0, 0)));
    	enemies.addAll(dungeon.getAllEntitiesOfType(new Troll(null, 0, 0)));
    	
    	for (Entity e: enemies) {
    		if ((Math.abs(e.getX() - this.getX()) <= 1 && e.getY() == this.getY()) ||
    	    	(Math.abs(e.getY() - this.getY()) <= 1 && e.getX() == this.getX())) {
    			
    			if (dungeon.getGoal() != null)
    				dungeon.getGoal().incCount("enemies");
				dungeon.removeEntity(e);
    		}
    	}
    	
    	enemies = dungeon.getAllEntitiesOfType(new Enemy(null, 0, 0));
    	enemies.addAll(dungeon.getAllEntitiesOfType(new Hound(null, 0, 0)));
    	enemies.addAll(dungeon.getAllEntitiesOfType(new Gnome(null, 0, 0)));
    	enemies.addAll(dungeon.getAllEntitiesOfType(new Troll(null, 0, 0)));
    	
    	
    	if (enemies.size() == 0) {
    		dungeon.notifyGoal("enemies");
    	}
    	
    	
    	// Wall destruction
    	List<Entity> walls = dungeon.getAllEntitiesOfType(new Wall(null, 0, 0));
    	
    	for (Entity w: walls) {
    		if ((Math.abs(w.getX() - this.getX()) <= 1 && w.getY() == this.getY()) ||
    	    	(Math.abs(w.getY() - this.getY()) <= 1 && w.getX() == this.getX())) {
				dungeon.removeEntity(w);
    		}
    	}
    }
    
    private void delete() {
    	dungeon.removeEntity(this);
    }
    
    @Override
    public void update(Observable o, Object args) {
    	if (o instanceof Player) {
    		Player p = (Player) o;
    		if (!(this.active) && p.getX() == this.getX() && p.getY() == this.getY()) {
    			dungeon.removeEntity(this);
    			//Add treasure to inventory
    			p.getInventory().addBomb();
    		}
    		
    		if (this.active) {
    			this.decTimer();
    		}
    	}
    }
}
