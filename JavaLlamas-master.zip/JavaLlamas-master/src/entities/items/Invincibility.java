package entities.items;

import java.util.Observable;
import unsw.dungeon.Dungeon;
import java.util.Observer;

import entities.Entity;
import entities.Player;

public class Invincibility extends Entity implements Observer {
	private Dungeon dungeon;

    public Invincibility(Dungeon dungeon, int x, int y) {
        super(dungeon, x, y);
        this.dungeon = dungeon;
        
        if (dungeon != null && dungeon.getPlayer() != null) {
        	dungeon.getPlayer().addObserver(this);
        }
    }
    
    public boolean observesPlayer() {
    	return true;
    }
    
    public void observePlayer(Player p) {
    	p.addObserver(this);
    }
    
    @Override
    public void update(Observable o, Object args) {
    	if (o instanceof Player) {
    		Player p = (Player) o;
    		
    		if (p.getX() == this.getX() && p.getY() == this.getY()) {
    			dungeon.removeEntity(this);
    			//Add potion to inventory
    			p.getInventory().addInvincibility();
    		}
    	}
    }
}
