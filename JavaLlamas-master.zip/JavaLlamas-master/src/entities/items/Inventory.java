package entities.items;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;


public class Inventory {
	//For a certain player
	private int keyId = -14921;

	private IntegerProperty swordUses = new SimpleIntegerProperty(0);
	private IntegerProperty bowUses = new SimpleIntegerProperty(0);
	private IntegerProperty bombUses = new SimpleIntegerProperty(0);
	private IntegerProperty invincibilityUses = new SimpleIntegerProperty(0);
	private IntegerProperty treasureCollected = new SimpleIntegerProperty(0);
	private BooleanProperty hasKey = new SimpleBooleanProperty(false);
	

	private boolean isConfused = false;
	private IntegerProperty confusionUses = new SimpleIntegerProperty(0);
	
	public boolean getConfusionStatus() {
		return isConfused;
	}
	
	public void setConfusionStatus(Boolean input) {
		isConfused = input;
	}
	
	public int getConfusionUses() {
		return confusionUses.get();
	}
	public void addConfusion() {
		confusionUses.set(getConfusionUses() + 5);
	}
	public void decConfusion() {
		confusionUses.set(getConfusionUses() - 1);
	}
	
	public IntegerProperty getObservableConfusion() {
		return confusionUses;
	}

	public int getSwordUses() {
		return swordUses.get();
	}
	
	public int getBowUses() {
		return bowUses.get();
	}
	
	public int getBombUses() {
		return bombUses.get();
	}
	
	public int getInvincibilityUses() {
		return invincibilityUses.get();
	}
	
	public boolean addSword() {
		if (getSwordUses() == 0 && getBowUses() == 0) {
			swordUses.set(getSwordUses() + 5);
			return true;
		}
		return false;
	}
	
	public boolean addArrow() {
		if (getSwordUses() == 0) {
			bowUses.set(getBowUses() + 1);
			return true;
		}
		return false;
	}
	
	public void addBomb() {
		bombUses.set(getBombUses() + 1);
	}
	
	public void addInvincibility() {
		invincibilityUses.set(getInvincibilityUses() + 10);
	}
	
	public void decSword() {
		//Attack function will check sword uses, if <=0 then cannot use a sword anymore
		swordUses.set(getSwordUses() - 1);
	}
	
	public void decBow() {
		//Attack function will check bow uses, if <=0 then cannot use a bow anymore
		bowUses.set(getBowUses() - 1);
	}
	
	public void decInvincibility() {
		invincibilityUses.set(getInvincibilityUses() - 1);
		//Every turn, this decreases.
	}
	
	public void decBomb() {
		bombUses.set(getBombUses() - 1);
	}
	
	public int getTreasureCollected() {
		return treasureCollected.get();
	}
	
	public void addTreasure() {
		treasureCollected.set(getTreasureCollected() + 1);
	}

	public void addKey(int id) {
		keyId = id;
		hasKey.set(true);
	}
	
	public int getKeyId() {
		return keyId;
	}
	
	public boolean hasKey() {
		return hasKey.get();
	}
	
	public void takeKey() {
		hasKey.set(false);
	}
	

	public IntegerProperty getObservableSword() {
		return swordUses;
	}
	
	public IntegerProperty getObservableBow() {
		return bowUses;
	}
	
	public IntegerProperty getObservableBomb() {
		return bombUses;
	}
	public IntegerProperty getObservableInvinc() {
		return invincibilityUses;
	}
	public IntegerProperty getObservableTreas() {
		return treasureCollected;
	}
	public BooleanProperty getObservableKey() {
		return hasKey;
	}
}
