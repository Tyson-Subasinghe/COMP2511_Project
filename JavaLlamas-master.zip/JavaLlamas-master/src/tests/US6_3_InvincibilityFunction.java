package tests;

import entities.*;
import entities.enemies.Enemy;
import entities.items.Invincibility;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class US6_3_InvincibilityFunction {
	Dungeon emptyDungeon;
	Player defaultPlayer;
	Invincibility invincibility1;
	Invincibility invincibility2;
	Invincibility invincibility3;
	Invincibility invincibility4;
	Enemy defaultEnemy;
	
	@BeforeEach
	void setUp() {
		emptyDungeon = new Dungeon(null, 10, 10);
		defaultPlayer = new Player(emptyDungeon, 5, 5);
		emptyDungeon.setPlayer(defaultPlayer);
		emptyDungeon.addEntity(defaultPlayer);
		
		defaultEnemy = new Enemy(emptyDungeon, 8,5);
		emptyDungeon.addEntity(defaultEnemy);
		//He will go to 7,5 when the player collects a potion to the right. 
		
		invincibility1 = new Invincibility(emptyDungeon,5,6);
		invincibility2 = new Invincibility(emptyDungeon,5,4);
		invincibility3 = new Invincibility(emptyDungeon,4,5);
		invincibility4 = new Invincibility(emptyDungeon,6,5);

		emptyDungeon.addEntity(new Wall(emptyDungeon, 9, 6));
		emptyDungeon.addEntity(new Wall(emptyDungeon, 9, 4));
	}
	
	
	@Test
	void testCollectInvincibilityInUpDirection() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 4);
		
		assertEquals(defaultPlayer.getInventory().getInvincibilityUses(),10);
		assertEquals(emptyDungeon.getAllEntitiesOfType(invincibility1).contains(invincibility2),
			     false);
	}
	
	@Test
	void testCollectInvincibilityInDownDirection() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6);
		
		assertEquals(defaultPlayer.getInventory().getInvincibilityUses(),10);
		assertEquals(emptyDungeon.getAllEntitiesOfType(invincibility1).contains(invincibility1),
			     false);
	}
	
	@Test
	void testCollectInvincibilityInLeftDirection() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveLeft();
		assertEquals(defaultPlayer.getX(), 4);
		
		assertEquals(defaultPlayer.getInventory().getInvincibilityUses(),10);
		assertEquals(emptyDungeon.getAllEntitiesOfType(invincibility1).contains(invincibility3),
			     false);
	}
	
	@Test
	void testCollectInvincibilityInRightDirection() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 6);
		
		assertEquals(defaultPlayer.getInventory().getInvincibilityUses(),10);
		assertEquals(emptyDungeon.getAllEntitiesOfType(invincibility1).contains(invincibility4),
				     false);
	}
	
	//Now we know, we can collect t in all directions.
	
	@Test
	void testEnemyRunsAway() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 6);
		assertEquals(defaultPlayer.getInventory().getInvincibilityUses(),10);
		
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 7);
		assertEquals(defaultEnemy.getX(), 9);
		//We now know that enemy runs away
	}
	
	@Test
	void testEnemyDiesOnContact() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getInventory().getInvincibilityUses(),10);
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getInventory().getInvincibilityUses(),9);
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getInventory().getInvincibilityUses(),8);
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getInventory().getInvincibilityUses(),7);
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getInventory().getInvincibilityUses(),6);
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getInventory().getInvincibilityUses(),5);
		defaultPlayer.moveRight();
		
		assertEquals(defaultPlayer.getX(), 9);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(defaultEnemy).contains(defaultEnemy), false);
	}
	
	void testDuration() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveRight();
		defaultPlayer.moveLeft();
		
		defaultPlayer.moveRight();
		defaultPlayer.moveLeft();
		
		defaultPlayer.moveRight();
		defaultPlayer.moveLeft();
		
		defaultPlayer.moveRight();
		defaultPlayer.moveLeft();
		
		defaultPlayer.moveRight();
		defaultPlayer.moveLeft();
		
		defaultPlayer.moveRight();
		defaultPlayer.moveLeft();
		
		//It has been >10 turns
		assertEquals(defaultPlayer.getInventory().getInvincibilityUses(),0);
		
		//Now we know that duration runs out
	}
	

}
