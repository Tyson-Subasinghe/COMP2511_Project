package tests;

import entities.*;
import entities.enemies.Enemy;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class EnemyMockDungeon extends Dungeon {
	private boolean notified;
	private String goal;
	private String message;
	
	public EnemyMockDungeon(DungeonLoader loader, int width, int height) {
		super(loader, width, height);
		
		this.notified = false;
	}
	
	public void notifyDeath() {
    	this.notified = true;
    }
	
	public boolean getNotified() {
		return notified;
	}
}

class US3_5_KilledWhenMeetingEnemy {
	EnemyMockDungeon mockDungeon;
	Player defaultPlayer;
	
	@BeforeEach
	void setUp() {
		mockDungeon = new EnemyMockDungeon(null, 10, 10);
		defaultPlayer = new Player(mockDungeon, 5, 5);
		mockDungeon.setPlayer(defaultPlayer);
		mockDungeon.addEntity(defaultPlayer);
		
		mockDungeon.addEntity(new Wall(mockDungeon, 5,6));
	}
	
	@Test
	void testPlayerMovingOntoEnemy() {
		mockDungeon.addEntity(new Enemy(mockDungeon, 4, 5));		
		
		assertEquals(mockDungeon.getNotified(), false);
		
		defaultPlayer.moveLeft();
		
		assertEquals(mockDungeon.getNotified(), true);
	}
	
	@Test
	void testEnemyMovingOntoPlayer() {
		mockDungeon.addEntity(new Enemy(mockDungeon, 4, 5));		
		
		assertEquals(mockDungeon.getNotified(), false);
		
		defaultPlayer.moveDown();
		
		assertEquals(mockDungeon.getNotified(), true);
	}
}
