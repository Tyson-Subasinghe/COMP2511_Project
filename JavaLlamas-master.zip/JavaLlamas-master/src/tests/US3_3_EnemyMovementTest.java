package tests;

import entities.*;
import entities.enemies.Enemy;
import entities.goalComponents.Boulder;
import entities.goalComponents.Switch;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class US3_3_EnemyMovementTest {
	Dungeon emptyDungeon;
	Player defaultPlayer;
	Enemy enemy;
	
	@BeforeEach
	void setUp() {
		emptyDungeon = new Dungeon(null, 10, 10);
		defaultPlayer = new Player(emptyDungeon, 0, 0);
		emptyDungeon.setPlayer(defaultPlayer);
		emptyDungeon.addEntity(defaultPlayer);

		enemy = new Enemy(emptyDungeon, 9, 9);
		enemy = new Enemy(emptyDungeon, 9, 9);
	}
	
	@Test
	void testMovementIsEuclidean() {
		defaultPlayer.moveDown();

		assertEquals(enemy.getX(), 8);
		assertEquals(enemy.getY(), 9);
		
		defaultPlayer.moveRight();
		
		assertEquals(enemy.getX(), 8);
		assertEquals(enemy.getY(), 8);

		defaultPlayer.moveRight();
		assertEquals(enemy.getX(), 8);
		assertEquals(enemy.getY(), 7);
	}
	
	@Test
	void testEnemyMovingIntoSolidTile() {
		emptyDungeon.addEntity(new Wall(emptyDungeon, 8,9));
		
		defaultPlayer.moveDown();
		
		assertNotEquals(enemy.getX(), 8);
	}

	@Test
	void testEnemyMovingIntoSpecialTile() {
		emptyDungeon.addEntity(new Boulder(emptyDungeon, 8,9));
		
		defaultPlayer.moveDown();
		
		assertNotEquals(enemy.getX(), 8);
	}
	
	@Test
	void testEnemyMovingIntoNonSolidTile() {
		emptyDungeon.addEntity(new Switch(emptyDungeon, 8,9));
		
		defaultPlayer.moveDown();
		
		assertEquals(enemy.getX(), 8);
		assertEquals(enemy.getY(), 9);
	}

	@Test
	void testEnemyMovingIntoEmptyTile() {
		defaultPlayer.moveDown();
		
		assertEquals(enemy.getX(), 8);
		assertEquals(enemy.getY(), 9);
	}

	@Test
	void testEnemyMovingIntoPlayer() {
		//NOTE: Using a new player here to avoid triggering a win condition
		emptyDungeon.addEntity(new Player(emptyDungeon, 8,9));
		
		defaultPlayer.moveDown();
		
		assertEquals(enemy.getX(), 8);
		assertEquals(enemy.getY(), 9);
	}

	@Test
	void testEnemyMovingIntoMultipleEntitiesOnATile() {
		emptyDungeon.addEntity(new Switch(emptyDungeon, 8,9));

		defaultPlayer.moveDown();
		
		assertEquals(enemy.getX(), 8);
		assertEquals(enemy.getY(), 9);
		
		emptyDungeon.addEntity(new Player(emptyDungeon, 7,9));
		emptyDungeon.addEntity(new Switch(emptyDungeon, 7,9));
		
		defaultPlayer.moveDown();
		
		assertEquals(enemy.getX(), 7);
		assertEquals(enemy.getY(), 9);
		
		emptyDungeon.addEntity(new Player(emptyDungeon, 6,9));
		emptyDungeon.addEntity(new Boulder(emptyDungeon, 6,9));
		
		defaultPlayer.moveDown();
		
		assertEquals(enemy.getX(), 7);
		assertEquals(enemy.getY(), 8);
		
		emptyDungeon.addEntity(new Wall(emptyDungeon, 6,8));
		
		defaultPlayer.moveDown();
		
		assertNotEquals(enemy.getX(), 6);
	}
}
