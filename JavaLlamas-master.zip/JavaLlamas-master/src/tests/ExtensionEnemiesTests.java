package tests;

import entities.*;
import entities.enemies.Gnome;
import entities.enemies.Hound;
import entities.enemies.TrappedTreasure;
import entities.enemies.Troll;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class ExtensionEnemiesTests {
	Dungeon emptyDungeon;
	Player defaultPlayer;
	
	@BeforeEach
	void setUp() {
		emptyDungeon = new Dungeon(null, 10, 10);
		defaultPlayer = new Player(emptyDungeon, 5, 5);
		emptyDungeon.setPlayer(defaultPlayer);
		emptyDungeon.addEntity(defaultPlayer);
	}
	
	@Test
	void testTrollMovesSlow() {
		Troll troll = new Troll(emptyDungeon, 0, 0);
		emptyDungeon.addEntity(troll);
		
		assertEquals(troll.getX(), 0);
		assertEquals(troll.getY(), 0);
		
		defaultPlayer.moveDown();
		
		assertEquals(troll.getX(), 0);
		assertEquals(troll.getY(), 0);
		
		defaultPlayer.moveDown();
		
		assertEquals(troll.getX(), 0);
		assertEquals(troll.getY(), 1);
	}
	
	@Test
	void testTrollStompsPlayer() {
		Troll troll = new Troll(emptyDungeon, 5, 2);
		emptyDungeon.addEntity(troll);
		
		assertEquals(troll.getX(), 5);
		assertEquals(troll.getY(), 2);
		
		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		
		assertEquals(troll.getX(), 5);
		assertEquals(troll.getY(), 3);
	}
	
	@Test
	void testTrollClubAttack() {
		Troll troll = new Troll(emptyDungeon, 5, 3);
		emptyDungeon.addEntity(troll);
		
		assertEquals(troll.getX(), 5);
		assertEquals(troll.getY(), 3);
		assertEquals(troll.getObservableRaising().get(), false);
		
		defaultPlayer.moveUp();
		
		assertEquals(troll.getX(), 5);
		assertEquals(troll.getY(), 3);
		assertEquals(troll.getObservableRaising().get(), true);
		
		defaultPlayer.moveLeft();
		assertEquals(troll.getObservableRaising().get(), false);
		assertEquals(troll.getObservableAttacking().get(), true);
		
		defaultPlayer.moveLeft();
		assertEquals(troll.getObservableAttacking().get(), false);
	}
	
	@Test
	void testTrollHP() {
		Troll troll = new Troll(emptyDungeon, 5, 3);
		emptyDungeon.addEntity(troll);
		
		defaultPlayer.getInventory().addSword();
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(troll).size(), 1);

		defaultPlayer.moveUp();
		defaultPlayer.attackUp();
		defaultPlayer.moveLeft();
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(troll).size(), 1);

		defaultPlayer.attackRight();
		defaultPlayer.moveUp();
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(troll).size(), 1);
		
		defaultPlayer.attackDown();
		defaultPlayer.moveLeft();
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(troll).size(), 0);
	}
	
	@Test
	void testBombKillsTroll() {
		Troll troll = new Troll(emptyDungeon, 5, 3);
		emptyDungeon.addEntity(troll);
		
		defaultPlayer.getInventory().addBomb();
		defaultPlayer.placeBomb(5, 5);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(troll).size(), 1);

		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(troll).size(), 0);
	}
	
	@Test
	void testHoundMovesSlow() {
		Hound hound = new Hound(emptyDungeon, 0, 0);
		emptyDungeon.addEntity(hound);
		
		assertEquals(hound.getX(), 0);
		assertEquals(hound.getY(), 0);
		
		defaultPlayer.moveDown();
		
		assertEquals(hound.getX(), 0);
		assertEquals(hound.getY(), 1);
		
		defaultPlayer.moveDown();
		
		assertEquals(hound.getX(), 0);
		assertEquals(hound.getY(), 1);
	}
	
	@Test
	void testHoundCanBeKilled() {
		Hound hound = new Hound(emptyDungeon, 5, 4);
		emptyDungeon.addEntity(hound);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(hound).size(), 1);
		
		defaultPlayer.getInventory().addSword();
		defaultPlayer.attackUp();
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(hound).size(), 0);
	}
	
	@Test
	void testTrappedTreasureDoesNothing() {
		TrappedTreasure treas = new TrappedTreasure(emptyDungeon, 5, 4);
		emptyDungeon.addEntity(treas);

		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		
		assertEquals(treas.getX(), 5);
		assertEquals(treas.getY(), 4);
	}
	
	@Test
	void testTrappedTreasureSpawnsGnome() {
		TrappedTreasure treas = new TrappedTreasure(emptyDungeon, 5, 4);
		emptyDungeon.addEntity(treas);

		assertEquals(emptyDungeon.getAllEntitiesOfType(treas).size(), 1);

		defaultPlayer.moveUp();

		assertEquals(emptyDungeon.getAllEntitiesOfType(treas).size(), 0);
		assertEquals(emptyDungeon.getAllEntitiesOfType(new Gnome(null,0,0)).size(), 1);
	}
	
	@Test
	void testGnomeMovesAndDies() {
		Gnome gnome = new Gnome(emptyDungeon, 5, 4);
		emptyDungeon.addEntity(gnome);

		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		
		assertEquals(gnome.getX(), 5);
		assertEquals(gnome.getY(), 6);

		defaultPlayer.getInventory().addSword();
		defaultPlayer.attackUp();

		assertEquals(emptyDungeon.getAllEntitiesOfType(gnome).size(), 0);
	}
}
