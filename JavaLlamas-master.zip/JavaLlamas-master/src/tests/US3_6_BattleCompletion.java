package tests;

import entities.*;
import entities.enemies.Enemy;
import goals.Goal;
import goals.MazeGoal;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class MockAtkDungeon extends Dungeon {
	private boolean notified;
	private String goal;
	
	public MockAtkDungeon(DungeonLoader loader, int width, int height) {
		super(loader, width, height);
		
		this.notified = false;
		this.goal = "";
	}
	
	public void notifyGoal(String goal) {
    	this.notified = true;
    	this.goal = goal;
    }
	
	public boolean getNotified() {
		return notified;
	}
	
	public String getGoalTxt() {
		return goal;
	}
}

class US3_6_BattleCompletion {
	MockAtkDungeon mockDungeon;
	Player defaultPlayer;
	
	@BeforeEach
	void setUp() {
		mockDungeon = new MockAtkDungeon(null, 10, 10);
		Goal goal = new MazeGoal();
		mockDungeon.setGoal(goal);
		defaultPlayer = new Player(mockDungeon, 5, 5);
		mockDungeon.setPlayer(defaultPlayer);
		mockDungeon.addEntity(defaultPlayer);
		defaultPlayer.getInventory().addSword();
	}
	
	@Test
	void testNotKillingNothingHappens() {
		mockDungeon.addEntity(new Enemy(mockDungeon, 0, 0));
		defaultPlayer.moveDown();
		
		assertEquals(mockDungeon.getNotified(), false);
	}
	
	@Test
	void testKillingTriggersGoal() {
		mockDungeon.addEntity(new Enemy(mockDungeon, 5, 6));
		defaultPlayer.attackDown();
		
		assertEquals(mockDungeon.getNotified(), true);
		assertEquals(mockDungeon.getGoalTxt(), "enemies");
	}
	
	@Test
	void testKillingMultiTriggersGoal() {
		mockDungeon.addEntity(new Enemy(mockDungeon, 5, 6));
		mockDungeon.addEntity(new Enemy(mockDungeon, 5, 7));
		defaultPlayer.attackDown();
		assertEquals(mockDungeon.getNotified(), false);
		defaultPlayer.attackDown();
		
		assertEquals(mockDungeon.getNotified(), true);
		assertEquals(mockDungeon.getGoalTxt(), "enemies");
	}
}
