package tests;

import entities.*;
import entities.enemies.Enemy;
import entities.items.Sword;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class US3_4_AttackTest {
	Dungeon emptyDungeon;
	Player defaultPlayer;
	Sword sword;
	
	Enemy enemy1; 
	Enemy enemy2; 
	Enemy enemy3; 
	Enemy enemy4; 
	
	
	@BeforeEach
	void setUp() {
		emptyDungeon = new Dungeon(null, 10, 10);
		defaultPlayer = new Player(emptyDungeon, 5, 5);
		emptyDungeon.setPlayer(defaultPlayer);
		emptyDungeon.addEntity(defaultPlayer);
		defaultPlayer.getInventory().addSword();
		
		enemy1 = new Enemy(emptyDungeon,5,6);
		emptyDungeon.addEntity(enemy1);
		enemy2 = new Enemy(emptyDungeon,5,4);
		emptyDungeon.addEntity(enemy2);
		enemy3 = new Enemy(emptyDungeon,4,5);
		emptyDungeon.addEntity(enemy3);
		enemy4 = new Enemy(emptyDungeon,6,5);
		emptyDungeon.addEntity(enemy4);
		

		
	}
	
	@Test
	void canAttackAllDirectionsWithoutErrors() {
		defaultPlayer.attackUp();
		defaultPlayer.attackDown();
		defaultPlayer.attackLeft();
		defaultPlayer.attackRight();
	}
	
	@Test
	void testEnemyDeadDown() {
		//Enemy moves to -1,-1 when they die, so if attacking works they will die
		defaultPlayer.attackDown();
		assertEquals(emptyDungeon.getAllEntitiesOfType(enemy1).contains(enemy1),false);
		assertEquals(defaultPlayer.getInventory().getSwordUses(), 4);
	}
		
	@Test
	void testEnemyDeadUp() {
		defaultPlayer.attackUp();
		assertEquals(emptyDungeon.getAllEntitiesOfType(enemy1).contains(enemy2),false);
		assertEquals(defaultPlayer.getInventory().getSwordUses(), 4);
	}

	@Test
	void testEnemyDeadLeft() {
		defaultPlayer.attackLeft();
		assertEquals(emptyDungeon.getAllEntitiesOfType(enemy1).contains(enemy3),false);
		assertEquals(defaultPlayer.getInventory().getSwordUses(), 4);
	}

	@Test
	void testEnemyDeadRight() {
		defaultPlayer.attackRight();
		assertEquals(emptyDungeon.getAllEntitiesOfType(enemy1).contains(enemy4),false);
		assertEquals(defaultPlayer.getInventory().getSwordUses(), 4);
	}
}
