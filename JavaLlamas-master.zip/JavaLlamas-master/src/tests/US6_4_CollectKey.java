package tests;

import entities.*;
import entities.items.Key;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class US6_4_CollectKey {
	Dungeon emptyDungeon;
	Player defaultPlayer;
	Key key1;
	Key key2;
	Key key3;
	Key key4;
	
	@BeforeEach
	void setUp() {
		emptyDungeon = new Dungeon(null, 10, 10);
		defaultPlayer = new Player(emptyDungeon, 5, 5);
		emptyDungeon.setPlayer(defaultPlayer);
		emptyDungeon.addEntity(defaultPlayer);
		
		key1 = new Key(emptyDungeon,5,6,5);
		key2 = new Key(emptyDungeon,5,4,6);
		key3 = new Key(emptyDungeon,4,5,7);
		key4 = new Key(emptyDungeon,6,5,8);

		emptyDungeon.addEntity(key1);
		emptyDungeon.addEntity(key2);
		emptyDungeon.addEntity(key3);
		emptyDungeon.addEntity(key4);
	}
	
	
	@Test
	void testCollectKeyInUpDirectionKeyRemoved() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 4);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(key1).contains(key2), false);
	}
	
	@Test
	void testCollectKeyInDownDirectionKeyRemoved() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(key1).contains(key1), false);
	}
	
	@Test
	void testCollectKeyInLeftDirectionKeyRemoved() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveLeft();
		assertEquals(defaultPlayer.getX(), 4);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(key1).contains(key3), false);
	}
	
	@Test
	void testCollectKeyInRightDirectionKeyRemoved() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 6);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(key1).contains(key4), false);
	}
	
	@Test
	void testCollectKeyInUpDirectionCorrectId() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		assertEquals(defaultPlayer.holdsKey(6), false);
		
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 4);
		
		//Need to check key no longer exists NOTE MAY NEED TO REMOVE THIS
		assertEquals(defaultPlayer.holdsKey(5), false);
		assertEquals(defaultPlayer.holdsKey(6), true);
		assertEquals(defaultPlayer.holdsKey(7), false);
		assertEquals(defaultPlayer.holdsKey(8), false);
		
	
	}
	
	@Test
	void testCollectKeyInDownDirectionCorrectId() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		assertEquals(defaultPlayer.holdsKey(5), false);
		
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6);
		
		//Need to check key no longer exists NOTE MAY NEED TO REMOVE THIS
		assertEquals(defaultPlayer.holdsKey(5), true);
		assertEquals(defaultPlayer.holdsKey(6), false);
		assertEquals(defaultPlayer.holdsKey(7), false);
		assertEquals(defaultPlayer.holdsKey(8), false);
		
	}
	
	@Test
	void testCollectKeyInLeftDirectionCorrectId() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		assertEquals(defaultPlayer.holdsKey(7), false);
		
		defaultPlayer.moveLeft();
		assertEquals(defaultPlayer.getX(), 4);
		
		//Need to check key no longer exists NOTE MAY NEED TO REMOVE THIS
		assertEquals(defaultPlayer.holdsKey(5), false);
		assertEquals(defaultPlayer.holdsKey(6), false);
		assertEquals(defaultPlayer.holdsKey(7), true);
		assertEquals(defaultPlayer.holdsKey(8), false);
		
	}
	
	@Test
	void testCollectKeyInRightDirectionCorrectId() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		assertEquals(defaultPlayer.holdsKey(8), false);
		
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 6);
		
		//Need to check key no longer exists NOTE MAY NEED TO REMOVE THIS
		assertEquals(defaultPlayer.holdsKey(5), false);
		assertEquals(defaultPlayer.holdsKey(6), false);
		assertEquals(defaultPlayer.holdsKey(7), false);
		assertEquals(defaultPlayer.holdsKey(8), true);
		
	}
	

	@Test
	void testCannotCollectMultipleKeys() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6);
		defaultPlayer.moveLeft();
		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 5);
		assertEquals(defaultPlayer.getX(), 6);
		
		//Need to check key no longer exists NOTE MAY NEED TO REMOVE THIS
		assertEquals(defaultPlayer.holdsKey(5), true);
		assertEquals(defaultPlayer.holdsKey(6), false);
		assertEquals(defaultPlayer.holdsKey(7), false);
		assertEquals(defaultPlayer.holdsKey(8), false);
		
	}
}
