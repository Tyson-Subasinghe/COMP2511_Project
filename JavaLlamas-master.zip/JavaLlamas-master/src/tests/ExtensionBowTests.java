package tests;

import entities.*;
import entities.enemies.Enemy;
import entities.goalComponents.Boulder;
import entities.goalComponents.Switch;
import entities.items.Arrow;
import entities.items.Bow;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class ExtensionBowTests {
	Dungeon emptyDungeon;
	Player defaultPlayer;
	
	@BeforeEach
	void setUp() {
		emptyDungeon = new Dungeon(null, 10, 10);
		defaultPlayer = new Player(emptyDungeon, 5, 5);
		emptyDungeon.setPlayer(defaultPlayer);
		emptyDungeon.addEntity(defaultPlayer);
	}
	
	@Test
	void testPickUpBow() {
		Bow bow = new Bow(emptyDungeon, 5, 4);
		emptyDungeon.addEntity(bow);
		
		defaultPlayer.moveUp();
		
		assertEquals(defaultPlayer.getInventory().getBowUses(), 1);
	}
	
	@Test
	void testPickUpArrows() {
		emptyDungeon.addEntity(new Arrow(emptyDungeon, 5, 4));
		emptyDungeon.addEntity(new Arrow(emptyDungeon, 5, 3));
		emptyDungeon.addEntity(new Arrow(emptyDungeon, 5, 2));
		
		defaultPlayer.moveUp();
		
		assertEquals(defaultPlayer.getInventory().getBowUses(), 0);

		defaultPlayer.getInventory().addArrow();
		defaultPlayer.moveDown();
		defaultPlayer.moveUp();
		
		assertEquals(defaultPlayer.getInventory().getBowUses(), 2);
		
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getInventory().getBowUses(), 3);
		
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getInventory().getBowUses(), 4);
	}
	
	@Test
	void testFireArrowAtWall() {
		emptyDungeon.addEntity(new Wall(emptyDungeon, 5, 1));
		
		defaultPlayer.getInventory().addArrow();
		defaultPlayer.attackUp();

		assertEquals(emptyDungeon.getAllEntitiesOfType(new Arrow(null,0,0)).size(), 1);
		assertEquals(emptyDungeon.getTileEntities(5,2).size(), 1);
	}
	
	@Test
	void testFireArrowAtTopOfDungeon() {
		defaultPlayer.getInventory().addArrow();
		defaultPlayer.attackUp();

		assertEquals(emptyDungeon.getAllEntitiesOfType(new Arrow(null,0,0)).size(), 1);
		assertEquals(emptyDungeon.getTileEntities(5,0).size(), 1);
	}
	
	@Test
	void testFireArrowThroughNonSolidEntity() {
		emptyDungeon.addEntity(new Switch(emptyDungeon, 5, 1));
		
		defaultPlayer.getInventory().addArrow();
		defaultPlayer.attackUp();

		assertEquals(emptyDungeon.getAllEntitiesOfType(new Arrow(null,0,0)).size(), 1);
		assertEquals(emptyDungeon.getTileEntities(5,0).size(), 1);
	}
	
	@Test
	void testFireArrowAtBoulder() {
		emptyDungeon.addEntity(new Boulder(emptyDungeon, 5, 1));
		
		defaultPlayer.getInventory().addArrow();
		defaultPlayer.attackUp();

		assertEquals(emptyDungeon.getAllEntitiesOfType(new Arrow(null,0,0)).size(), 1);
		assertEquals(emptyDungeon.getTileEntities(5,2).size(), 1);
	}
	
	@Test
	void testFireArrowAtEnemy() {
		emptyDungeon.addEntity(new Enemy(emptyDungeon, 5, 1));
		
		defaultPlayer.getInventory().addArrow();
		defaultPlayer.attackUp();

		assertEquals(emptyDungeon.getAllEntitiesOfType(new Arrow(null,0,0)).size(), 1);
		assertEquals(emptyDungeon.getTileEntities(5,2).get(0) instanceof Arrow, true);
	}
}
