package tests;

import entities.*;
import entities.goalComponents.Exit;
import goals.Goal;
import goals.MazeGoal;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import javafx.embed.swing.JFXPanel;

import org.junit.jupiter.api.BeforeEach;

class DungeonLoaderMessageCapture extends DungeonControllerLoader {
	private String message = "";
	
	public DungeonLoaderMessageCapture(List<String> filenames) throws FileNotFoundException {
		super(filenames);
	}
	
	public void handleCompletedLevel(String message) {
		this.message = message;
	}
	
	public String getMsg() {
		return message;
	}
	
	public void refreshDungeon() {
    	reRenderLevel();
	}
}

class US1_5_LevelCompletionTest {
	
	@BeforeEach
	void setUp() {
		new JFXPanel();
	}
	
	@Test
	void testMessageIsSentForMaze() {
		try {
			DungeonLoaderMessageCapture mockDL = new DungeonLoaderMessageCapture(new ArrayList<String>());
			Dungeon dummyDungeon = new Dungeon(mockDL, 10, 10);
			Goal goal = new MazeGoal();
			dummyDungeon.setGoal(goal);
			Player defaultPlayer = new Player(dummyDungeon, 5, 5);
			dummyDungeon.setPlayer(defaultPlayer);
			dummyDungeon.addEntity(defaultPlayer);
			dummyDungeon.addEntity(new Exit(dummyDungeon, 5, 6));

			assertEquals(mockDL.getMsg(), "");
			
			defaultPlayer.moveDown();
			
			Thread.sleep(500); // Need to wait, due to concurrency issues.
			
			assertEquals(mockDL.getMsg(), "You found the exit to the maze! You win!", "If this test fails, run it individually. It is sensitive to time of test execution.");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			assertEquals(true, false); // Dungeon Loader incorrectly raised FileNotFoundException
		} catch (InterruptedException e) {
			e.printStackTrace();
			assertEquals(true, false); // sleep had interrupt exception.
		}
	}
	
	//NOTE: exit cannot be tested, as it would stop the test. However, it has been manually tested.
	
	@Test
	void testResetLevelResetsEntityPosition() {
		ArrayList<String> files = new ArrayList<String>();
		files.add("maze.json");
		
		try {
			DungeonLoaderMessageCapture mockDL = new DungeonLoaderMessageCapture(files);
			mockDL.loadLevel();
			Dungeon maze = mockDL.getCurrDungeon();

			assertEquals(maze.getPlayer().getX(), 1);
			assertEquals(maze.getPlayer().getY(), 1);
			
			maze.getPlayer().moveDown();
			
			assertEquals(maze.getPlayer().getX(), 1);
			assertEquals(maze.getPlayer().getY(), 2);
			
			mockDL.loadLevel();
	    	mockDL.refreshDungeon();
			maze = mockDL.getCurrDungeon();

			assertEquals(maze.getPlayer().getX(), 1);
			assertEquals(maze.getPlayer().getY(), 1);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			assertEquals(true, false); // Dungeon Loader incorrectly raised FileNotFoundException
		}
	}
	
	@Test
	void testContinueLoadsNextLevel() {
		ArrayList<String> files = new ArrayList<String>();
		files.add("maze.json");
		files.add("boulders.json");
		
		try {
			DungeonLoaderMessageCapture mockDL = new DungeonLoaderMessageCapture(files);
			mockDL.loadLevel();
			Dungeon maze = mockDL.getCurrDungeon();

			assertEquals(maze.getPlayer().getX(), 1);
			assertEquals(maze.getPlayer().getY(), 1);
			
			assertEquals(mockDL.goToNextDungeon(), true);
	    	mockDL.refreshDungeon();
			maze = mockDL.getCurrDungeon();

			assertEquals(maze.getPlayer().getX(), 2);
			assertEquals(maze.getPlayer().getY(), 2);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			assertEquals(true, false); // Dungeon Loader incorrectly raised FileNotFoundException
		}
	}
	

	@Test
	void testCannotLoadNextLevelAfterFinishingAllLevels() {
		ArrayList<String> files = new ArrayList<String>();
		files.add("maze.json");
		
		try {
			DungeonLoaderMessageCapture mockDL = new DungeonLoaderMessageCapture(files);
			mockDL.loadLevel();
			Dungeon maze = mockDL.getCurrDungeon();

			assertEquals(maze.getPlayer().getX(), 1);
			assertEquals(maze.getPlayer().getY(), 1);

			assertEquals(mockDL.goToNextDungeon(), false);
			assertEquals(mockDL.goToNextDungeon(), false);
			assertEquals(mockDL.goToNextDungeon(), false);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			assertEquals(true, false); // Dungeon Loader incorrectly raised FileNotFoundException
		}
	}
}
