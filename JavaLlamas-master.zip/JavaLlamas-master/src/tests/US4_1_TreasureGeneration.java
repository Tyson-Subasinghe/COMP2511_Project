package tests;

import entities.*;
import goals.Goal;
import goals.TreasureGoal;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import javafx.embed.swing.JFXPanel;

import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;


class US4_1_TreasureGeneration {
	
	@BeforeEach
	void setUp() {
		new JFXPanel();
	}
	
	@Test
	void testTreasureGeneratedBySingleGoalType() {
		JSONObject exitGoalJSON = new JSONObject("{ \"goal\": \"treasure\" }");
		Goal exitGoal = DungeonLoader.generateGoal(exitGoalJSON);

		assertEquals(exitGoal instanceof TreasureGoal, true);
		//Should create a single goal
		assertEquals(exitGoal.getCompleted(),false);
		//The single goal should not be completed
		
		
	}

}
