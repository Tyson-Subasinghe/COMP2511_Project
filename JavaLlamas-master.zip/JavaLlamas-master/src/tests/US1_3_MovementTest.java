package tests;

import entities.*;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class US1_3_MovementTest {
	Dungeon emptyDungeon;
	Player defaultPlayer;
	
	@BeforeEach
	void setUp() {
		emptyDungeon = new Dungeon(null, 10, 10);
		defaultPlayer = new Player(emptyDungeon, 5, 5);
		emptyDungeon.setPlayer(defaultPlayer);
		emptyDungeon.addEntity(defaultPlayer);
	}
	
	@Test
	void canMoveAllDirectionsWithoutErrors() {
		defaultPlayer.moveUp();
		defaultPlayer.moveDown();
		defaultPlayer.moveLeft();
		defaultPlayer.moveRight();
	}
	
	@Test
	void testDistanceMovedAndDirectionMoved() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 4);
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6);
		
		defaultPlayer.moveLeft();
		assertEquals(defaultPlayer.getX(), 4);
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 6);
	}

	@Test
	void testMovingOutOfBounds() {
		for (int i = 0; i < 100; i++) {
			defaultPlayer.moveUp();
		}
		assertEquals(defaultPlayer.getY(), 0, "Player should stop at the top of the dungeon.");
		

		for (int i = 0; i < 100; i++) {
			defaultPlayer.moveDown();
		}
		assertEquals(defaultPlayer.getY(), 9, "Player should stop at the bottom of the dungeon.");
		

		for (int i = 0; i < 100; i++) {
			defaultPlayer.moveLeft();
		}
		assertEquals(defaultPlayer.getX(), 0, "Player should stop at the left of the dungeon.");
		
		
		for (int i = 0; i < 100; i++) {
			defaultPlayer.moveRight();
		}
		assertEquals(defaultPlayer.getX(), 9, "Player should stop at the right of the dungeon.");
	}
	
	@Test
	void testMovingIntoSingleSolidTile() {
		emptyDungeon.addEntity(new Wall(emptyDungeon, 5,6));
		emptyDungeon.addEntity(new Wall(emptyDungeon, 5,4));
		emptyDungeon.addEntity(new Wall(emptyDungeon, 6,5));
		emptyDungeon.addEntity(new Wall(emptyDungeon, 4,5));

		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 5, "Player should not move up into a solid tile.");
		
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 5, "Player should not move down into a solid tile.");
		
		defaultPlayer.moveLeft();
		assertEquals(defaultPlayer.getX(), 5, "Player should not move left into a solid tile.");
		
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 5, "Player should not move right into a solid tile.");
	}
	
	@Test
	void testMovingIntoNonSolidEntity() {
		// Simplest test is that the player is a non-solid entity; no dungeon should be created like this.
		// However, for this unit test we want as few implemented entities as possible (to allow early testing).
		emptyDungeon.addEntity(new Player(emptyDungeon,5,6));
		emptyDungeon.addEntity(new Player(emptyDungeon,5,4));
		emptyDungeon.addEntity(new Player(emptyDungeon,6,5));
		emptyDungeon.addEntity(new Player(emptyDungeon,4,5));

		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 4, "Player should move up into a non-solid tile.");
		defaultPlayer.moveDown();
		
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6, "Player should move down into a non-solid tile.");
		defaultPlayer.moveUp();
		
		defaultPlayer.moveLeft();
		assertEquals(defaultPlayer.getX(), 4, "Player should move left into a non-solid tile.");
		defaultPlayer.moveRight();
		
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 6, "Player should move right into a non-solid tile.");
	}
	
	@Test
	void testMovingOntoTileWithMultipleEntities() {
		emptyDungeon.addEntity(new Player(emptyDungeon,5,6));
		emptyDungeon.addEntity(new Player(emptyDungeon,5,6));
		emptyDungeon.addEntity(new Player(emptyDungeon,5,4));
		emptyDungeon.addEntity(new Wall(emptyDungeon, 5,4));
		

		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 5, "Player should not move into a tile with at least one solid entity.");
		
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6, "Player should move into a tile with many non-solid entities.");
		
	}
}
