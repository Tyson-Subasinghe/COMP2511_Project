package tests;

import entities.*;
import entities.goalComponents.Boulder;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class US2_2_BoulderTest {
	Dungeon emptyDungeon;
	Player defaultPlayer;
	
	@BeforeEach
	void setUp() {
		emptyDungeon = new Dungeon(null, 10, 10);
		defaultPlayer = new Player(emptyDungeon, 5, 5);
		emptyDungeon.setPlayer(defaultPlayer);
		emptyDungeon.addEntity(defaultPlayer);
	}
	
	@Test
	void testPushBoulderIntoFreeTile() {
		Boulder bDown = new Boulder(emptyDungeon, 5,6);
		Boulder bUp = new Boulder(emptyDungeon, 5,4);
		Boulder bLeft = new Boulder(emptyDungeon, 4,5);
		Boulder bRight = new Boulder(emptyDungeon, 6,5);
		emptyDungeon.addEntity(bUp);
		emptyDungeon.addEntity(bDown);
		emptyDungeon.addEntity(bLeft);
		emptyDungeon.addEntity(bRight);
		
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 4);
		assertEquals(bUp.getY(), 3);

		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6);
		assertEquals(bDown.getY(), 7);

		defaultPlayer.moveUp();
		defaultPlayer.moveLeft();
		assertEquals(defaultPlayer.getX(), 4);
		assertEquals(bLeft.getX(), 3);
		
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 6);
		assertEquals(bRight.getX(), 7);
	}
	
	@Test
	void testPushBoulderIntoWall() {
		Boulder bDown = new Boulder(emptyDungeon, 5,6);
		Boulder bUp = new Boulder(emptyDungeon, 5,4);
		Boulder bLeft = new Boulder(emptyDungeon, 4,5);
		Boulder bRight = new Boulder(emptyDungeon, 6,5);
		emptyDungeon.addEntity(bUp);
		emptyDungeon.addEntity(bDown);
		emptyDungeon.addEntity(bLeft);
		emptyDungeon.addEntity(bRight);

		emptyDungeon.addEntity(new Wall(emptyDungeon, 5,7));
		emptyDungeon.addEntity(new Wall(emptyDungeon, 5,3));
		emptyDungeon.addEntity(new Wall(emptyDungeon, 7,5));
		emptyDungeon.addEntity(new Wall(emptyDungeon, 3,5));
		
		
		
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 5);
		assertEquals(bUp.getY(), 4);

		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 5);
		assertEquals(bDown.getY(), 6);

		defaultPlayer.moveLeft();
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(bLeft.getX(), 4);
		
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(bRight.getX(), 6);
	}
	
	@Test
	void testPushBoulderOutOfBounds() {
		Boulder bDown = new Boulder(emptyDungeon, 5,9);
		Boulder bUp = new Boulder(emptyDungeon, 5,0);
		Boulder bLeft = new Boulder(emptyDungeon, 0,5);
		Boulder bRight = new Boulder(emptyDungeon, 9,5);
		emptyDungeon.addEntity(bUp);
		emptyDungeon.addEntity(bDown);
		emptyDungeon.addEntity(bLeft);
		emptyDungeon.addEntity(bRight);
		

		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 1);
		assertEquals(bUp.getY(), 0);

		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 8);
		assertEquals(bDown.getY(), 9);

		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		defaultPlayer.moveLeft();
		defaultPlayer.moveLeft();
		defaultPlayer.moveLeft();
		defaultPlayer.moveLeft();
		defaultPlayer.moveLeft();
		assertEquals(defaultPlayer.getX(), 1);
		assertEquals(bLeft.getX(), 0);

		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 8);
		assertEquals(bRight.getX(), 9);
	}
	
	@Test
	void testPushBoulderIntoBoulder() {
		Boulder bDown = new Boulder(emptyDungeon, 5,6);
		Boulder bUp = new Boulder(emptyDungeon, 5,4);
		Boulder bLeft = new Boulder(emptyDungeon, 4,5);
		Boulder bRight = new Boulder(emptyDungeon, 6,5);
		emptyDungeon.addEntity(bUp);
		emptyDungeon.addEntity(bDown);
		emptyDungeon.addEntity(bLeft);
		emptyDungeon.addEntity(bRight);

		emptyDungeon.addEntity(new Boulder(emptyDungeon, 5,7));
		emptyDungeon.addEntity(new Boulder(emptyDungeon, 5,3));
		emptyDungeon.addEntity(new Boulder(emptyDungeon, 7,5));
		emptyDungeon.addEntity(new Boulder(emptyDungeon, 3,5));
		
		
		
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 5);
		assertEquals(bUp.getY(), 4);

		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 5);
		assertEquals(bDown.getY(), 6);

		defaultPlayer.moveLeft();
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(bLeft.getX(), 4);
		
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(bRight.getX(), 6);
	}
	

	@Test
	void testPushBoulderIntoNonSolidEntity() {
		Boulder bDown = new Boulder(emptyDungeon, 5,6);
		Boulder bUp = new Boulder(emptyDungeon, 5,4);
		Boulder bLeft = new Boulder(emptyDungeon, 4,5);
		Boulder bRight = new Boulder(emptyDungeon, 6,5);
		emptyDungeon.addEntity(bUp);
		emptyDungeon.addEntity(bDown);
		emptyDungeon.addEntity(bLeft);
		emptyDungeon.addEntity(bRight);

		emptyDungeon.addEntity(new Player(emptyDungeon, 5,7));
		emptyDungeon.addEntity(new Player(emptyDungeon, 5,3));
		emptyDungeon.addEntity(new Player(emptyDungeon, 7,5));
		emptyDungeon.addEntity(new Player(emptyDungeon, 3,5));
		
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 4);
		assertEquals(bUp.getY(), 3);

		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6);
		assertEquals(bDown.getY(), 7);

		defaultPlayer.moveUp();
		defaultPlayer.moveLeft();
		assertEquals(defaultPlayer.getX(), 4);
		assertEquals(bLeft.getX(), 3);
		
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 6);
		assertEquals(bRight.getX(), 7);
	}
}
