package tests;

import entities.*;
import entities.goalComponents.Boulder;
import entities.goalComponents.Switch;
import goals.Goal;
import goals.MazeGoal;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;


class US2_3_SwitchesTest {
	Dungeon emptyDungeon;
	Player defaultPlayer;
	Switch sDown;
	Switch sUp;
	Switch sLeft;
	Switch sRight;
	
	@BeforeEach
	void setUp() {
		emptyDungeon = new Dungeon(null, 10, 10);
		Goal goal = new MazeGoal();
		emptyDungeon.setGoal(goal);
		defaultPlayer = new Player(emptyDungeon, 5, 5);
		emptyDungeon.setPlayer(defaultPlayer);
		emptyDungeon.addEntity(defaultPlayer);
		
		emptyDungeon.addEntity(new Boulder(emptyDungeon, 5,6));
		emptyDungeon.addEntity(new Boulder(emptyDungeon, 5,4));
		emptyDungeon.addEntity(new Boulder(emptyDungeon, 4,5));
		emptyDungeon.addEntity(new Boulder(emptyDungeon, 6,5));
		
		sDown = new Switch(emptyDungeon, 5,7);
		sUp = new Switch(emptyDungeon, 5,3);
		sLeft = new Switch(emptyDungeon, 3,5);
		sRight = new Switch(emptyDungeon, 7,5);
		emptyDungeon.addEntity(sUp);
		emptyDungeon.addEntity(sDown);
		emptyDungeon.addEntity(sLeft);
		emptyDungeon.addEntity(sRight);
	}
	
	@Test
	void testTriggerSwitch() {
		assertEquals(sUp.getTriggered(), false);
		assertEquals(sDown.getTriggered(), false);
		assertEquals(sLeft.getTriggered(), false);
		assertEquals(sRight.getTriggered(), false);
		
		defaultPlayer.moveUp();
		assertEquals(sUp.getTriggered(), true);
		assertEquals(sDown.getTriggered(), false);
		assertEquals(sLeft.getTriggered(), false);
		assertEquals(sRight.getTriggered(), false);

		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		assertEquals(sUp.getTriggered(), true);
		assertEquals(sDown.getTriggered(), true);
		assertEquals(sLeft.getTriggered(), false);
		assertEquals(sRight.getTriggered(), false);

		defaultPlayer.moveUp();
		defaultPlayer.moveLeft();
		assertEquals(sUp.getTriggered(), true);
		assertEquals(sDown.getTriggered(), true);
		assertEquals(sLeft.getTriggered(), true);
		assertEquals(sRight.getTriggered(), false);
		
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		assertEquals(sUp.getTriggered(), true);
		assertEquals(sDown.getTriggered(), true);
		assertEquals(sLeft.getTriggered(), true);
		assertEquals(sRight.getTriggered(), true);
	}
	
	@Test
	void testUntriggerSwitch() {
		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		defaultPlayer.moveLeft();
		defaultPlayer.moveLeft();
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		
		assertEquals(sUp.getTriggered(), false);
		assertEquals(sDown.getTriggered(), false);
		assertEquals(sLeft.getTriggered(), false);
		assertEquals(sRight.getTriggered(), false);
	}
}
