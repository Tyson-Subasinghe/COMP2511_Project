package tests;

import entities.*;
import entities.goalComponents.Exit;
import goals.Goal;
import goals.MazeGoal;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class MockDungeon extends Dungeon {
	private boolean notified;
	private String goal;
	
	public MockDungeon(DungeonLoader loader, int width, int height) {
		super(loader, width, height);
		
		this.notified = false;
		this.goal = "";
	}
	
	public void notifyGoal(String goal) {
    	this.notified = true;
    	this.goal = goal;
    }
	
	public boolean getNotified() {
		return notified;
	}
	
	public String getGoalTxt() {
		return goal;
	}
}

class US1_4_MazeCompletionTest {
	MockDungeon mockDungeon;
	Player defaultPlayer;
	
	@BeforeEach
	void setUp() {
		mockDungeon = new MockDungeon(null, 10, 10);
		Goal goal = new MazeGoal();
		mockDungeon.setGoal(goal);
		defaultPlayer = new Player(mockDungeon, 5, 5);
		mockDungeon.setPlayer(defaultPlayer);
		mockDungeon.addEntity(defaultPlayer);
	}
	
	@Test
	void testMovingOntoExitTriggersCorrectCall() {
		mockDungeon.addEntity(new Exit(mockDungeon, 5, 6));
		
		defaultPlayer.moveDown();
		
		//assertEquals(mockDungeon.getGoal().getCompleted(), true);
		assertEquals(mockDungeon.getNotified(), true);
		assertEquals(mockDungeon.getGoalTxt(), "exit");
	}
	
	@Test
	void testMovingWhenNoExitDoesntTrigger() {
		defaultPlayer.moveDown();
		defaultPlayer.moveUp();
		defaultPlayer.moveLeft();
		defaultPlayer.moveRight();

		assertEquals(mockDungeon.getNotified(), false);
		assertEquals(mockDungeon.getGoalTxt(), "");
		//assertEquals(mockDungeon.getGoal().getCompleted(), false);
	}
	
	@Test
	void testMovingOffExitDoesntTrigger() {
		mockDungeon.addEntity(new Exit(mockDungeon, 5, 5));
		
		defaultPlayer.moveDown();

		assertEquals(mockDungeon.getNotified(), false);
		assertEquals(mockDungeon.getGoalTxt(), "");
//		assertEquals(mockDungeon.getGoal().getCompleted(), false);
	}
	
	@Test
	void testMovingNearExitDoesntTrigger() {
		mockDungeon.addEntity(new Exit(mockDungeon, 5, 6));

		defaultPlayer.moveLeft();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		defaultPlayer.moveLeft();

//		assertEquals(mockDungeon.getGoal().getCompleted(), false);
		assertEquals(mockDungeon.getNotified(), false);
		assertEquals(mockDungeon.getGoalTxt(), "");
	}
	
	@Test
	void testMovingFarFromExitDoesntTrigger() {
		mockDungeon.addEntity(new Exit(mockDungeon, 0, 0));

		defaultPlayer.moveLeft();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveRight();
		defaultPlayer.moveRight();
		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		defaultPlayer.moveLeft();
		

//		assertEquals(mockDungeon.getGoal().getCompleted(), false);
		assertEquals(mockDungeon.getNotified(), false);
		assertEquals(mockDungeon.getGoalTxt(), "");
	}
}
