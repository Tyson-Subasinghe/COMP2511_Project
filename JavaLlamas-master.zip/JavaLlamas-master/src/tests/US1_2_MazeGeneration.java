package tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import goals.Goal;
import goals.MazeGoal;
import javafx.embed.swing.JFXPanel;
import unsw.dungeon.DungeonLoader;

import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;


class US1_2_MazeGeneration {

	@BeforeEach
	void setUp() {
		new JFXPanel();
	}

	@Test
	void testMazeGeneratedBySingleGoalType() {
		JSONObject exitGoalJSON = new JSONObject("{ \"goal\": \"exit\" }");
		Goal exitGoal = DungeonLoader.generateGoal(exitGoalJSON);

		assertEquals(exitGoal instanceof MazeGoal, true);
		//Should create a single goal
		assertEquals(exitGoal.getCompleted(),false);
		//The single goal should not be completed


	}

}
