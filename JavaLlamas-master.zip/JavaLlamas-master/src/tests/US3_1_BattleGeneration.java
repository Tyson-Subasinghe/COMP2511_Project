package tests;

import entities.*;
import goals.EnemiesGoal;
import goals.Goal;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import javafx.embed.swing.JFXPanel;

import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;


class US3_1_BattleGeneration {
	
	@BeforeEach
	void setUp() {
		new JFXPanel();
	}
	
	@Test
	void testBouldersGeneratedBySingleGoalType() {
		JSONObject exitGoalJSON = new JSONObject("{ \"goal\": \"enemies\" }");
		Goal exitGoal = DungeonLoader.generateGoal(exitGoalJSON);

		assertEquals(exitGoal instanceof EnemiesGoal, true);
		//Should create a single goal
		assertEquals(exitGoal.getCompleted(),false);
		//The single goal should not be completed
		
		
	}

}
