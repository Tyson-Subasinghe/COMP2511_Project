package tests;

import entities.*;
import entities.enemies.Enemy;
import goals.Goal;
import goals.MazeGoal;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import javafx.embed.swing.JFXPanel;

import org.junit.jupiter.api.BeforeEach;

class DungeonLoaderMessageCaptureLoss extends DungeonControllerLoader {
	private String message = "";
	
	public DungeonLoaderMessageCaptureLoss(List<String> filenames) throws FileNotFoundException {
		super(filenames);
	}
	
	public void handleDeath(String message) {
		this.message = message;
	}
	
	public String getMsg() {
		return message;
	}
	
	public void refreshDungeon() {
    	reRenderLevel();
	}
}

class US3_7_LevelLossTest {
	
	@BeforeEach
	void setUp() {
		new JFXPanel();
	}
	
	@Test
	void testMessageIsSentOnDeath() {
		try {
			DungeonLoaderMessageCaptureLoss mockDL = new DungeonLoaderMessageCaptureLoss(new ArrayList<String>());
			Dungeon dummyDungeon = new Dungeon(mockDL, 10, 10);
			Goal goal = new MazeGoal();
			dummyDungeon.setGoal(goal);
			Player defaultPlayer = new Player(dummyDungeon, 5, 5);
			dummyDungeon.setPlayer(defaultPlayer);
			dummyDungeon.addEntity(defaultPlayer);
			dummyDungeon.addEntity(new Enemy(dummyDungeon, 5, 6));

			assertEquals(mockDL.getMsg(), "");
			
			defaultPlayer.moveDown();
			
			Thread.sleep(200); // Need to wait, due to concurrency issues.
			
			assertEquals(mockDL.getMsg(), "You died.");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			assertEquals(true, false); // Dungeon Loader incorrectly raised FileNotFoundException
		} catch (InterruptedException e) {
			e.printStackTrace();
			assertEquals(true, false); // sleep had interrupt exception.
		}
	}
	
	//NOTE: exit cannot be tested, as it would stop the test. However, it has been manually tested.
	
	@Test
	void testResetLevelResetsEntityPosition() {
		ArrayList<String> files = new ArrayList<String>();
		files.add("maze.json");
		
		try {
			DungeonLoaderMessageCapture mockDL = new DungeonLoaderMessageCapture(files);
			mockDL.loadLevel();
			Dungeon maze = mockDL.getCurrDungeon();
			maze.addEntity(new Enemy(maze, 1, 3));

			assertEquals(maze.getPlayer().getX(), 1);
			assertEquals(maze.getPlayer().getY(), 1);
			
			maze.getPlayer().moveDown();
			
			assertEquals(maze.getPlayer().getX(), 1);
			assertEquals(maze.getPlayer().getY(), 2);
			
			mockDL.loadLevel();
	    	mockDL.refreshDungeon();
			maze = mockDL.getCurrDungeon();

			assertEquals(maze.getPlayer().getX(), 1);
			assertEquals(maze.getPlayer().getY(), 1);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			assertEquals(true, false); // Dungeon Loader incorrectly raised FileNotFoundException
		}
	}
	
	// Loading of next level is tested in US1.5, if US1.5 passes so should US3.7.
}
