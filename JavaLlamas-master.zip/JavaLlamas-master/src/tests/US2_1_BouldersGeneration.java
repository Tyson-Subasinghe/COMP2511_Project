package tests;

import entities.*;
import goals.BouldersGoal;
import goals.Goal;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import javafx.embed.swing.JFXPanel;

import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;


class US2_1_BouldersGeneration {
	
	@BeforeEach
	void setUp() {
		new JFXPanel();
	}
	
	@Test
	void testBouldersGeneratedBySingleGoalType() {
		JSONObject exitGoalJSON = new JSONObject("{ \"goal\": \"boulders\" }");
		Goal exitGoal = DungeonLoader.generateGoal(exitGoalJSON);

		assertEquals(exitGoal instanceof BouldersGoal, true);
		//Should create a single goal
		assertEquals(exitGoal.getCompleted(),false);
		//The single goal should not be completed
		
		
	}

}
