package tests;

import entities.*;
import entities.goalComponents.Exit;
import goals.Goal;
import goals.MultiGoalAnd;
import goals.MultiGoalOr;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import javafx.embed.swing.JFXPanel;

import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;


class US5_1_MultipleGoalGeneration {
	
	@BeforeEach
	void setUp() {
		new JFXPanel();
	}
	
	@Test
	void testMultipleGoalNotGeneratedBySingleGoalType() {
		JSONObject exitGoalJSON = new JSONObject("{ \"goal\": \"exit\" }");
		Goal exitGoal = DungeonLoader.generateGoal(exitGoalJSON);

		assertEquals(exitGoal instanceof MultiGoalOr, false);
		assertEquals(exitGoal instanceof MultiGoalAnd, false);
		
		
		JSONObject bGoalJSON = new JSONObject("{ \"goal\": \"boulders\" }");
		Goal bGoal = DungeonLoader.generateGoal(bGoalJSON);

		assertEquals(bGoal instanceof MultiGoalOr, false);
		assertEquals(bGoal instanceof MultiGoalAnd, false);
		
		
		JSONObject tGoalJSON = new JSONObject("{ \"goal\": \"treasure\" }");
		Goal tGoal = DungeonLoader.generateGoal(tGoalJSON);

		assertEquals(tGoal instanceof MultiGoalOr, false);
		assertEquals(tGoal instanceof MultiGoalAnd, false);
		
		
		JSONObject eGoalJSON = new JSONObject("{ \"goal\": \"enemies\" }");
		Goal eGoal = DungeonLoader.generateGoal(eGoalJSON);

		assertEquals(eGoal instanceof MultiGoalOr, false);
		assertEquals(eGoal instanceof MultiGoalAnd, false);
	}

	@Test
	void ableToCreateOr() {
		JSONObject orGoalJSON = new JSONObject("{ \"goal\":\"OR\", \"subgoals\": [" +
											   "{ \"goal\":\"exit\"}," +
											   "{ \"goal\":\"boulders\"}" +
											   "]}"); 
		Goal orGoal = DungeonLoader.generateGoal(orGoalJSON);
		
		assertNotEquals(orGoal, null);
		assertEquals(orGoal instanceof MultiGoalOr, true);
		assertEquals(orGoal instanceof MultiGoalAnd, false);
	}
	
	@Test
	void ableToCreateAnd() {
		JSONObject andGoalJSON = new JSONObject("{ \"goal\":\"AND\", \"subgoals\": [" +
											    "{ \"goal\":\"exit\"}," +
											    "{ \"goal\":\"boulders\"}" +
											    "]}"); 
		Goal andGoal = DungeonLoader.generateGoal(andGoalJSON);
		
		assertNotEquals(andGoal, null);
		assertEquals(andGoal instanceof MultiGoalOr, false);
		assertEquals(andGoal instanceof MultiGoalAnd, true);
	}
	
	@Test
	void parseCompoundGoal() {
		JSONObject mulGoalJSON = new JSONObject("{ \"goal\":\"AND\", \"subgoals\": [" +
												"{ \"goal\":\"OR\", \"subgoals\": [" +
													"{ \"goal\":\"exit\"}," +
													"{ \"goal\":\"enemies\"}," +
													"]}," +
											    "{ \"goal\":\"boulders\"}" +
											    "]}");
		
		Goal multiGoal = DungeonLoader.generateGoal(mulGoalJSON);
		assertEquals(multiGoal instanceof MultiGoalAnd, true);
		multiGoal.notifyGoal("none");
		
		assertEquals(multiGoal.getGoalProgress(),
					 "Complete all of the following:\n" +
					 "\tComplete any of the following:\n"+
				     "\t\tFind the exit.\n"+
					 "\t\tEnemies goal uninitialised\n"+
				     "\tSwitch goal uninitialised");
	}
	
	@Test
	void testIncAndDecCountIsPassedDown() {
		JSONObject mulGoalJSON = new JSONObject("{ \"goal\":\"AND\", \"subgoals\": [" +
												"{ \"goal\":\"OR\", \"subgoals\": [" +
													"{ \"goal\":\"exit\"}," +
													"{ \"goal\":\"enemies\"}," +
													"]}," +
											    "{ \"goal\":\"treasure\"}" +
											    "]}");

		Goal multiGoal = DungeonLoader.generateGoal(mulGoalJSON);

		multiGoal.incCount("enemies");
		
		assertEquals(multiGoal.getGoalProgress(),
					 "Complete all of the following:\n" +
					 "\tComplete any of the following:\n"+
				     "\t\tFind the exit.\n"+
					 "\t\tKill all enemies (-1 remaining).\n"+
				     "\tTreasure goal uninitialised");
		
		multiGoal.decCount("enemies");
		
		assertEquals(multiGoal.getGoalProgress(),
					 "Complete all of the following:\n" +
					 "\tComplete any of the following:\n"+
				     "\t\tFind the exit.\n"+
					 "\t\tKill all enemies (0 remaining).\n"+
				     "\tTreasure goal uninitialised");
	}
	
	@Test
	void testTriggerringSingleWinCondDoesntEndLevel() {
		JSONObject andGoalJSON = new JSONObject("{ \"goal\":\"AND\", \"subgoals\": [" +
			    "{ \"goal\":\"exit\"}," +
			    "{ \"goal\":\"boulders\"}" +
			    "]}"); 
		Goal andGoal = DungeonLoader.generateGoal(andGoalJSON);
		
		Dungeon emptyDungeon = new Dungeon(null, 10, 10);
		emptyDungeon.setGoal(andGoal);
		Player defaultPlayer = new Player(emptyDungeon, 5, 5);
		emptyDungeon.setPlayer(defaultPlayer);
		emptyDungeon.addEntity(defaultPlayer);
		
		emptyDungeon.addEntity(new Exit(emptyDungeon, 5,6));
		
		assertEquals(andGoal.getCompleted(), false);
		
		defaultPlayer.moveDown();

		assertEquals(andGoal.getCompleted(), false);
	}
}
