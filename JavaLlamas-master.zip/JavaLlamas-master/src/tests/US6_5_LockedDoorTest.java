package tests;

import entities.*;
import entities.items.Key;
import entities.items.LockedDoor;
import goals.Goal;
import goals.MazeGoal;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class MockLockDungeon extends Dungeon {
	private boolean notified;
	private String goal;
	
	public MockLockDungeon(DungeonLoader loader, int width, int height) {
		super(loader, width, height);
		
		this.notified = false;
		this.goal = "";
	}
	
	public void notifyGoal(String goal) {
    	this.notified = true;
    	this.goal = goal;
    }
	
	public boolean getNotified() {
		return notified;
	}
	
	public String getGoalTxt() {
		return goal;
	}
}

class US6_5_LockedDoorTest {
	MockLockDungeon mockDungeon;
	Player defaultPlayer;
	LockedDoor door;
	
	@BeforeEach
	void setUp() {
		mockDungeon = new MockLockDungeon(null, 10, 10);
		Goal goal = new MazeGoal();
		mockDungeon.setGoal(goal);
		defaultPlayer = new Player(mockDungeon, 5, 5);
		mockDungeon.setPlayer(defaultPlayer);
		mockDungeon.addEntity(defaultPlayer);
		
		door = new LockedDoor(mockDungeon, 5, 7, 5);
		mockDungeon.addEntity(door);
	}
	
	@Test
	void testMovingIntoDoorWithNoKey() {
		assertEquals(defaultPlayer.getY(), 5);
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6);
		assertEquals(mockDungeon.getNotified(), false);
		assertEquals(door.locked().get(), true);
	}
	
	@Test
	void testMovingIntoDoorWithWrongKey() {
		mockDungeon.addEntity(new Key(mockDungeon,5,6,6));

		assertEquals(defaultPlayer.getY(), 5);
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6);
		assertEquals(mockDungeon.getNotified(), false);
		assertEquals(door.locked().get(), true);
	}
	
	@Test
	void testMovingIntoDoorWithCorrectKey() {
		mockDungeon.addEntity(new Key(mockDungeon,5,6,5));

		assertEquals(defaultPlayer.getY(), 5);
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 7);
		assertEquals(mockDungeon.getNotified(), true);
		assertEquals(mockDungeon.getGoalTxt(), "exit");
		assertEquals(door.locked().get(), false);
	}
	
	@Test
	void testMovingIntoWrongDoorThenCorrectDoor() {
		mockDungeon.addEntity(new Key(mockDungeon,5,6,6));
		LockedDoor newDoor = new LockedDoor(mockDungeon,5,4,6);
		mockDungeon.addEntity(newDoor);

		assertEquals(defaultPlayer.getY(), 5);
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6);
		assertEquals(mockDungeon.getNotified(), false);
		assertEquals(door.locked().get(), true);
		
		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 4);
		assertEquals(mockDungeon.getNotified(), true);
		assertEquals(mockDungeon.getGoalTxt(), "exit");
		assertEquals(door.locked().get(), true);
		assertEquals(newDoor.locked().get(), false);
	}
}
