package tests;

import entities.*;
import entities.goalComponents.Boulder;
import entities.goalComponents.Switch;
import goals.BouldersGoal;
import goals.Goal;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class SwitchGoalMockDungeon extends Dungeon {
	private boolean notified;
	private String goal;
	
	public SwitchGoalMockDungeon(DungeonLoader loader, int width, int height) {
		super(loader, width, height);
		
		this.notified = false;
		this.goal = "";
	}
	
	public void notifyGoal(String goal) {
    	this.notified = true;
    	this.goal = goal;
    }
	
	public boolean getNotified() {
		return notified;
	}
	
	public String getGoalTxt() {
		return goal;
	}
}

class US2_4_BoulderCompletionTest {
	SwitchGoalMockDungeon mockDungeon;
	Player defaultPlayer;
	
	@BeforeEach
	void setUp() {
		mockDungeon = new SwitchGoalMockDungeon(null, 10, 10);
		Goal goal = new BouldersGoal();
		mockDungeon.setGoal(goal);
		defaultPlayer = new Player(mockDungeon, 5, 5);
		mockDungeon.setPlayer(defaultPlayer);
		mockDungeon.addEntity(defaultPlayer);
	}
	
	@Test
	void testSingleBoulderOntoSingleButton() {
		mockDungeon.addEntity(new Boulder(mockDungeon, 5,6));
		mockDungeon.addEntity(new Switch(mockDungeon, 5,7));
		
		defaultPlayer.moveDown();

		assertEquals(mockDungeon.getNotified(), true);
		assertEquals(mockDungeon.getGoalTxt(), "boulders");
//		assertEquals(mockDungeon.getGoal().getCompleted(), true);
	}
	
	@Test
	void testMultipleSwitchesAllPressed() {
		mockDungeon.addEntity(new Boulder(mockDungeon, 5,6));
		mockDungeon.addEntity(new Switch(mockDungeon, 5,7));
		mockDungeon.addEntity(new Boulder(mockDungeon, 5,4));
		mockDungeon.addEntity(new Switch(mockDungeon, 5,3));

		defaultPlayer.moveDown();

		assertEquals(mockDungeon.getNotified(), false);
		assertEquals(mockDungeon.getGoalTxt(), "");
//		assertEquals(mockDungeon.getGoal().getCompleted(), false);

		defaultPlayer.moveUp();
		defaultPlayer.moveUp();

		assertEquals(mockDungeon.getNotified(), true);
		assertEquals(mockDungeon.getGoalTxt(), "boulders");
//		assertEquals(mockDungeon.getGoal().getCompleted(), true);
	}
	
	@Test
	void testMovingBoulderOffButtonThenBackOn() {
		mockDungeon.addEntity(new Boulder(mockDungeon, 5,6));
		mockDungeon.addEntity(new Switch(mockDungeon, 5,7));
		mockDungeon.addEntity(new Boulder(mockDungeon, 5,4));
		mockDungeon.addEntity(new Switch(mockDungeon, 5,3));

		defaultPlayer.moveDown();
		defaultPlayer.moveDown();

		assertEquals(mockDungeon.getNotified(), false);
		assertEquals(mockDungeon.getGoalTxt(), "");
//		assertEquals(mockDungeon.getGoal().getCompleted(), false);
		
		defaultPlayer.moveUp();
		defaultPlayer.moveUp();
		defaultPlayer.moveUp();

		assertEquals(mockDungeon.getNotified(), false);
		assertEquals(mockDungeon.getGoalTxt(), "");
//		assertEquals(mockDungeon.getGoal().getCompleted(), false);
		

		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveLeft();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveDown();
		defaultPlayer.moveRight();

		assertEquals(mockDungeon.getNotified(), false);
		assertEquals(mockDungeon.getGoalTxt(), "");
//		assertEquals(mockDungeon.getGoal().getCompleted(), false);
		
		defaultPlayer.moveUp();

		assertEquals(mockDungeon.getNotified(), true);
		assertEquals(mockDungeon.getGoalTxt(), "boulders");
//		assertEquals(mockDungeon.getGoal().getCompleted(), true);
	}
}
