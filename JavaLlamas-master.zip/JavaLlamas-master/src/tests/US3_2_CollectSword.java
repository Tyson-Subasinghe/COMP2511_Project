package tests;

import entities.*;
import entities.items.Sword;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class US3_2_CollectSword {
	Dungeon emptyDungeon;
	Player defaultPlayer;
	Sword sword1;
	Sword sword2;
	Sword sword3;
	Sword sword4;
	
	@BeforeEach
	void setUp() {
		emptyDungeon = new Dungeon(null, 10, 10);
		defaultPlayer = new Player(emptyDungeon, 5, 5);
		emptyDungeon.setPlayer(defaultPlayer);
		emptyDungeon.addEntity(defaultPlayer);
		
		sword1 = new Sword(emptyDungeon,5,6);
		sword2 = new Sword(emptyDungeon,5,4);
		sword3 = new Sword(emptyDungeon,4,5);
		sword4 = new Sword(emptyDungeon,6,5);
	}
	
	
	@Test
	void testCollectSwordInUpDirection() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 4);
		
		assertEquals(defaultPlayer.getInventory().getSwordUses(),5);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(sword1).contains(sword2), false);
		
	
	}
	
	@Test
	void testCollectSwordInDownDirection() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6);
		
		assertEquals(defaultPlayer.getInventory().getSwordUses(),5);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(sword1).contains(sword1), false);
		
	}
	
	@Test
	void testCollectSwordInLeftDirection() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveLeft();
		assertEquals(defaultPlayer.getX(), 4);
		
		assertEquals(defaultPlayer.getInventory().getSwordUses(),5);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(sword1).contains(sword3), false);
	}
	
	@Test
	void testCollectSwordInRightDirection() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 6);
		
		assertEquals(defaultPlayer.getInventory().getSwordUses(),5);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(sword1).contains(sword4), false);
	}

}
