package tests;

import entities.*;
import entities.goalComponents.Treasure;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

class US4_2_CollectTreasure {
	Dungeon emptyDungeon;
	Player defaultPlayer;
	Treasure treasure1;
	Treasure treasure2;
	Treasure treasure3;
	Treasure treasure4;
	
	@BeforeEach
	void setUp() {
		emptyDungeon = new Dungeon(null, 10, 10);
		defaultPlayer = new Player(emptyDungeon, 5, 5);
		emptyDungeon.setPlayer(defaultPlayer);
		emptyDungeon.addEntity(defaultPlayer);
		
		treasure1 = new Treasure(emptyDungeon,5,6);
		treasure2 = new Treasure(emptyDungeon,5,4);
		treasure3 = new Treasure(emptyDungeon,4,5);
		treasure4 = new Treasure(emptyDungeon,6,5);
		
	}
	
	
	@Test
	void testCollectTreasureInUpDirection() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveUp();
		assertEquals(defaultPlayer.getY(), 4);
		
		assertEquals(defaultPlayer.getInventory().getTreasureCollected(),1);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(treasure1).contains(treasure2), false);	
	}
	
	@Test
	void testCollectTreasureInDownDirection() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveDown();
		assertEquals(defaultPlayer.getY(), 6);
		
		assertEquals(defaultPlayer.getInventory().getTreasureCollected(),1);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(treasure1).contains(treasure1), false);
		
	}
	
	@Test
	void testCollectTreasureInLeftDirection() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveLeft();
		assertEquals(defaultPlayer.getX(), 4);
		
		assertEquals(defaultPlayer.getInventory().getTreasureCollected(),1);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(treasure1).contains(treasure3), false);
		
	}
	
	@Test
	void testCollectTreasureInRightDirection() {
		assertEquals(defaultPlayer.getX(), 5);
		assertEquals(defaultPlayer.getY(), 5);
		
		defaultPlayer.moveRight();
		assertEquals(defaultPlayer.getX(), 6);
		
		assertEquals(defaultPlayer.getInventory().getTreasureCollected(),1);
		
		assertEquals(emptyDungeon.getAllEntitiesOfType(treasure1).contains(treasure4), false);
		
	}

}
