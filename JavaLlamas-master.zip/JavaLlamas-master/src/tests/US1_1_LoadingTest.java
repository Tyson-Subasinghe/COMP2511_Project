package tests;

import entities.*;
import entities.enemies.Enemy;
import entities.enemies.Hound;
import entities.enemies.Troll;
import entities.goalComponents.Boulder;
import entities.goalComponents.Exit;
import entities.goalComponents.Switch;
import entities.goalComponents.Treasure;
import entities.items.Bomb;
import entities.items.Confusion;
import entities.items.Invincibility;
import entities.items.Key;
import entities.items.LockedDoor;
import entities.items.Sword;
import goals.Goal;
import unsw.dungeon.*;

import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import javafx.embed.swing.JFXPanel;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

class US1_1_LoadingTest {
	private List<String> filenames;
	
	@BeforeEach
	void setup() {
		new JFXPanel();
    	filenames = new ArrayList<String>();
    	filenames.add("advanced.json");
    	filenames.add("advancedWithEnemy.json");
    	filenames.add("boulders.json");
    	filenames.add("enemyPathfindTest.json");
    	filenames.add("maze.json");
    	filenames.add("simpleMazeNBoulders.json");
    	filenames.add("simpleMazeOrBoulders.json");
    	filenames.add("simpleMultiKeyTest.json");
    	filenames.add("simpleSingleKeyTest.json");
	}
	
	@Test
    void testDungeonCreation() {
    	for (String filename: filenames) {
			try {
		    	List<String> files = new ArrayList<String>();
		    	files.add(filename);
		    	DungeonLoader loader;
				loader = new DungeonControllerLoader(files);
		    	loader.loadLevel();
		    	Dungeon d = loader.getCurrDungeon();
		    	
		    	assertNotEquals(d, null);
	
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				assertEquals(true, false, "Dungeon loader couldn't open json test data.");
			}
    	}
    }
    
    @Test
    void testWallsAreSolid() {
    	for (String filename: filenames) {
			try {
		    	List<String> files = new ArrayList<String>();
		    	files.add(filename);
		    	DungeonLoader loader;
				loader = new DungeonControllerLoader(files);
		    	loader.loadLevel();
		    	Dungeon d = loader.getCurrDungeon();
		    	
		    	for (Entity e: d.getAllEntitiesOfType(new Entity(null, 0,0))) {
		    		if (e instanceof Wall) {
		    			assertEquals(e.isSpecial(), false);
		    			assertEquals(e.isSolid(), true);
		    		}
		    	}
	
			} catch (FileNotFoundException e) {
				assertEquals(true, false, "Dungeon loader couldn't open json test data.");
			}
    	}
    }
    
    @Test
    void testSpecialTiles() {
    	for (String filename: filenames) {
			try {
		    	List<String> files = new ArrayList<String>();
		    	files.add(filename);
		    	DungeonLoader loader;
				loader = new DungeonControllerLoader(files);
		    	loader.loadLevel();
		    	Dungeon d = loader.getCurrDungeon();
		    	
		    	for (Entity e: d.getAllEntitiesOfType(new Entity(null, 0,0))) {
		    		if (e instanceof Boulder || e instanceof Enemy || e instanceof LockedDoor) {
		    			assertEquals(e.isSpecial(), true);
		    		}
		    	}
	
			} catch (FileNotFoundException e) {
				assertEquals(true, false, "Dungeon loader couldn't open json test data.");
			}
    	}
    }
    
    @Test
    void testNonSolidTiles() {
    	for (String filename: filenames) {
			try {
		    	List<String> files = new ArrayList<String>();
		    	files.add(filename);
		    	DungeonLoader loader;
				loader = new DungeonControllerLoader(files);
		    	loader.loadLevel();
		    	Dungeon d = loader.getCurrDungeon();
		    	
		    	for (Entity e: d.getAllEntitiesOfType(new Entity(null, 0,0))) {
		    		if (e instanceof Player ||
		    			(e instanceof Exit && !(e instanceof LockedDoor)) ||
		    			e instanceof Switch ||
		    			e instanceof Sword ||
		    			e instanceof Treasure ||
		    			e instanceof Key ||
		    			e instanceof Bomb ||
		    			e instanceof Invincibility) {
		    			assertEquals(e.isSpecial(), false);
		    			assertEquals(e.isSolid(), false);
		    		}
		    	}
	
			} catch (FileNotFoundException e) {
				assertEquals(true, false, "Dungeon loader couldn't open json test data.");
			}
    	}
    }
    
    @Test
    void testGoalCreation() {
    	for (String filename: filenames) {
	    	try {
		    	List<String> files = new ArrayList<String>();
		    	files.add(filename);
		    	DungeonLoader loader;
				loader = new DungeonControllerLoader(files);
		    	loader.loadLevel();
		    	Dungeon d = loader.getCurrDungeon();
		    	
		    	JSONObject goalJSON = new JSONObject(new JSONTokener(new FileReader("dungeons/" + filename)));
		    	goalJSON = goalJSON.getJSONObject("goal-condition");
		    	Goal dummyGoal = DungeonLoader.generateGoal(goalJSON);
		    	dummyGoal.initCounts(d);
		    	
		    	// No need to check format of goals, will be done in individual loading tests.
		    	String progress = d.getGoal().getGoalProgress().replace("1", "0");
		    	progress = progress.replace("2", "0");
		    	progress = progress.replace("3", "0");
		    	progress = progress.replace("4", "0");
		    	progress = progress.replace("5", "0");
		    	progress = progress.replace("6", "0");
		    	progress = progress.replace("7", "0");
		    	progress = progress.replace("8", "0");
		    	progress = progress.replace("9", "0");
		    	
		    	String dummyProgress = dummyGoal.getGoalProgress().replace("1", "0");
		    	dummyProgress = dummyProgress.replace("2", "0");
		    	dummyProgress = dummyProgress.replace("3", "0");
		    	dummyProgress = dummyProgress.replace("4", "0");
		    	dummyProgress = dummyProgress.replace("5", "0");
		    	dummyProgress = dummyProgress.replace("6", "0");
		    	dummyProgress = dummyProgress.replace("7", "0");
		    	dummyProgress = dummyProgress.replace("8", "0");
		    	dummyProgress = dummyProgress.replace("9", "0");
		    	assertEquals(progress, dummyProgress);
			} catch (FileNotFoundException e) {
				assertEquals(true, false, "Dungeon loader couldn't open json test data.");
			}
    	}
    }
    
    private boolean checkType(Entity e, String type) {
    	switch (type) {
        case "player":
            return e instanceof Player;
        case "wall":
            return e instanceof Wall;
        case "exit":
            return e instanceof Exit && !(e instanceof LockedDoor);
        case "boulder":
            return e instanceof Boulder;
        case "switch":
            return e instanceof Switch;
        case "enemy":
            return e instanceof Enemy;
        case "sword":
            return e instanceof Sword;
        case "treasure":
            return e instanceof Treasure;
        case "bomb":
            return e instanceof Bomb;
        case "invincibility":
            return e instanceof Invincibility;
        case "door":
            return e instanceof LockedDoor;
        case "key":
            return e instanceof Key;
        case "hound":
            return e instanceof Hound;
        case "troll":
            return e instanceof Troll;
        case "confusion":
            return e instanceof Confusion;
        }
    	
    	return false;
    }
    
    @Test
    void testObjectPlacementIsCorrect() {
    	for (String filename: filenames) {
	    	try {
		    	List<String> files = new ArrayList<String>();
		    	files.add(filename);
		    	DungeonLoader loader;
				loader = new DungeonControllerLoader(files);
		    	loader.loadLevel();
		    	Dungeon d = loader.getCurrDungeon();
		    	
		    	JSONObject dJSON = new JSONObject(new JSONTokener(new FileReader("dungeons/" + filename)));
		    	JSONArray jsonEntities = dJSON.getJSONArray("entities");
		    	
		    	for (int i = 0; i < jsonEntities.length(); i++) {
		            int x = jsonEntities.getJSONObject(i).getInt("x");
		            int y = jsonEntities.getJSONObject(i).getInt("y");
		            String type = jsonEntities.getJSONObject(i).getString("type");
		    		
		    		boolean correct = false;
		    		for (Entity e: d.getTileEntities(x,y)) {
		    			if (checkType(e, type)) {
		    				correct = true;
		    				break;
		    			}
		    		}
		    		
		    		assertEquals(correct, true);
		        }
			} catch (FileNotFoundException e) {
				assertEquals(true, false, "Dungeon loader couldn't open json test data.");
			}
    	}
    }
}
