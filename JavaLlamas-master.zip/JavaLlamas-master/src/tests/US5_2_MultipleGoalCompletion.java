package tests;

import entities.*;
import entities.goalComponents.Exit;
import goals.BouldersGoal;
import goals.EnemiesGoal;
import goals.Goal;
import goals.MazeGoal;
import goals.MultiGoalAnd;
import goals.MultiGoalOr;
import goals.TreasureGoal;
import unsw.dungeon.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import javafx.embed.swing.JFXPanel;

import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;


class US5_2_MultipleGoalCompletion {
	
	@BeforeEach
	void setUp() {
		new JFXPanel();
	}
	
	@Test
	void testMultiGoalsAreUpdatedWhenTriggered() {
		JSONObject andGoalJSON = new JSONObject("{ \"goal\":\"AND\", \"subgoals\": [" +
											    "{ \"goal\":\"exit\"}," +
											    "{ \"goal\":\"boulders\"}" +
											    "]}"); 
		Goal andGoal = DungeonLoader.generateGoal(andGoalJSON);
		
		Dungeon emptyDungeon = new Dungeon(null, 10, 10);
		emptyDungeon.setGoal(andGoal);
		Player defaultPlayer = new Player(emptyDungeon, 5, 5);
		emptyDungeon.setPlayer(defaultPlayer);
		emptyDungeon.addEntity(defaultPlayer);
		emptyDungeon.addEntity(new Exit(emptyDungeon, 5,6));
		
		andGoal.notifyGoal("boulders");
		
		assertEquals(andGoal.getCompleted(), false);
		
		defaultPlayer.moveDown();

		assertEquals(andGoal.getCompleted(), true);
		
		defaultPlayer.moveUp();
		
		
		
		
		JSONObject orGoalJSON = new JSONObject("{ \"goal\":\"OR\", \"subgoals\": [" +
											    "{ \"goal\":\"exit\"}," +
											    "{ \"goal\":\"boulders\"}" +
											    "]}"); 
		Goal orGoal = DungeonLoader.generateGoal(orGoalJSON);
		emptyDungeon.setGoal(orGoal);
		
		assertEquals(orGoal.getCompleted(), false);
		
		defaultPlayer.moveDown();

		assertEquals(orGoal.getCompleted(), true);	
	}
	
	@Test
	void testGoalSatisfactionMatchesLogic() {
		Goal exit = new MazeGoal();
		Goal bdrs = new BouldersGoal();
		Goal enms = new EnemiesGoal();
		Goal trsr = new TreasureGoal();
		
		List<Goal> goalList = new ArrayList<Goal>();
		goalList.add(exit);
		goalList.add(bdrs);
		
		
		Goal simpleAnd = new MultiGoalAnd(goalList);
		
		assertEquals(simpleAnd.getCompleted(), false);
		simpleAnd.notifyGoal("exit");
		assertEquals(simpleAnd.getCompleted(), false);
		simpleAnd.notifyGoal("boulders");
		assertEquals(simpleAnd.getCompleted(), true);
		

		exit = new MazeGoal();
		bdrs = new BouldersGoal();
		enms = new EnemiesGoal();
		trsr = new TreasureGoal();
		
		goalList = new ArrayList<Goal>();
		goalList.add(exit);
		goalList.add(bdrs);
		
		Goal simpleOr = new MultiGoalOr(goalList);
		
		assertEquals(simpleOr.getCompleted(), false);
		simpleOr.notifyGoal("exit");
		assertEquals(simpleOr.getCompleted(), true);
		simpleOr = new MultiGoalOr(goalList);
		simpleOr.notifyGoal("boulders");
		assertEquals(simpleOr.getCompleted(), true);
		

		

		exit = new MazeGoal();
		bdrs = new BouldersGoal();
		enms = new EnemiesGoal();
		trsr = new TreasureGoal();
		
		goalList = new ArrayList<Goal>();
		goalList.add(exit);
		goalList.add(bdrs);
		goalList.add(enms);
		goalList.add(trsr);
		Goal largeAnd = new MultiGoalAnd(goalList);
		
		assertEquals(largeAnd.getCompleted(), false);
		largeAnd.notifyGoal("exit");
		assertEquals(largeAnd.getCompleted(), false);
		largeAnd.notifyGoal("boulders");
		assertEquals(largeAnd.getCompleted(), false);
		largeAnd.notifyGoal("enemies");
		assertEquals(largeAnd.getCompleted(), false);
		largeAnd.notifyGoal("treasure");
		assertEquals(largeAnd.getCompleted(), true);
	}
	
	@Test
	void testLargeMultiOrMatchesLogic() {
		Goal exit = new MazeGoal();
		Goal bdrs = new BouldersGoal();
		Goal enms = new EnemiesGoal();
		Goal trsr = new TreasureGoal();
		
		List<Goal> goalList = new ArrayList<Goal>();
		goalList.add(exit);
		goalList.add(bdrs);
		goalList.add(enms);
		goalList.add(trsr);
		Goal largeOr = new MultiGoalOr(goalList);
		assertEquals(largeOr.getCompleted(), false);
		largeOr.notifyGoal("exit");
		assertEquals(largeOr.getCompleted(), true);
		
		
		goalList.remove(exit);
		exit = new MazeGoal();
		goalList.add(exit);
		largeOr = new MultiGoalOr(goalList);
		assertEquals(largeOr.getCompleted(), false);
		largeOr.notifyGoal("boulders");
		assertEquals(largeOr.getCompleted(), true);
		
		
		goalList.remove(bdrs);
		bdrs = new BouldersGoal();
		goalList.add(bdrs);
		largeOr = new MultiGoalOr(goalList);
		assertEquals(largeOr.getCompleted(), false);
		largeOr.notifyGoal("enemies");
		assertEquals(largeOr.getCompleted(), true);
		
		
		goalList.remove(enms);
		enms = new EnemiesGoal();
		goalList.add(enms);
		largeOr = new MultiGoalOr(goalList);
		assertEquals(largeOr.getCompleted(), false);
		largeOr.notifyGoal("treasure");
		assertEquals(largeOr.getCompleted(), true);
	}
	
	@Test
	void testCompositionOfMultiGoals() {
		Goal exit = new MazeGoal();
		Goal bdrs = new BouldersGoal();
		Goal enms = new EnemiesGoal();
		
		List<Goal> goalList = new ArrayList<Goal>();
		goalList.add(exit);
		goalList.add(bdrs);
		
		
		Goal simpleOr = new MultiGoalOr(goalList);
		
		List<Goal> goalList2 = new ArrayList<Goal>();
		goalList2.add(simpleOr);
		goalList2.add(enms);
		
		
		Goal topGoal = new MultiGoalAnd(goalList2);

		assertEquals(topGoal.getCompleted(), false);
		topGoal.notifyGoal("enemies");
		assertEquals(topGoal.getCompleted(), false);
		topGoal.notifyGoal("exit");
		assertEquals(topGoal.getCompleted(), true);

		
		

		exit = new MazeGoal();
		bdrs = new BouldersGoal();
		enms = new EnemiesGoal();
		
		goalList = new ArrayList<Goal>();
		goalList.add(exit);
		goalList.add(bdrs);
		
		
		simpleOr = new MultiGoalOr(goalList);
		
		goalList2 = new ArrayList<Goal>();
		goalList2.add(simpleOr);
		goalList2.add(enms);
		topGoal = new MultiGoalAnd(goalList2);

		assertEquals(topGoal.getCompleted(), false);
		topGoal.notifyGoal("boulders");
		assertEquals(topGoal.getCompleted(), false);
		topGoal.notifyGoal("enemies");
		assertEquals(topGoal.getCompleted(), true);
	}

	@Test
	void testAndMessageCorrect() {
		Goal exit = new MazeGoal();
		Goal bdrs = new BouldersGoal();
		Goal enms = new EnemiesGoal();
		
		List<Goal> goalList = new ArrayList<Goal>();
		goalList.add(exit);
		goalList.add(bdrs);
		goalList.add(enms);
		
		
		Goal simpleAnd = new MultiGoalAnd(goalList);

		simpleAnd.notifyGoal("exit");
		simpleAnd.notifyGoal("boulders");
		simpleAnd.notifyGoal("enemies");
		
		assertEquals(simpleAnd.getMessage(), "found the exit to the maze and triggered all the switches and defeated all the enemies");
	}
	
	@Test
	void testOrMessageCorrect() {
		Goal exit = new MazeGoal();
		Goal bdrs = new BouldersGoal();
		Goal enms = new EnemiesGoal();
		
		List<Goal> goalList = new ArrayList<Goal>();
		goalList.add(exit);
		goalList.add(bdrs);
		goalList.add(enms);
		
		
		Goal simpleOr = new MultiGoalOr(goalList);
		simpleOr.notifyGoal("exit");
		assertEquals(simpleOr.getMessage(), "found the exit to the maze");
		

		exit = new MazeGoal();
		bdrs = new BouldersGoal();
		enms = new EnemiesGoal();
		
		goalList = new ArrayList<Goal>();
		goalList.add(exit);
		goalList.add(bdrs);
		goalList.add(enms);
		
		simpleOr = new MultiGoalOr(goalList);
		simpleOr.notifyGoal("boulders");
		assertEquals(simpleOr.getMessage(), "triggered all the switches");
		

		exit = new MazeGoal();
		bdrs = new BouldersGoal();
		enms = new EnemiesGoal();
		
		goalList = new ArrayList<Goal>();
		goalList.add(exit);
		goalList.add(bdrs);
		goalList.add(enms);

		simpleOr = new MultiGoalOr(goalList);
		simpleOr.notifyGoal("enemies");
		assertEquals(simpleOr.getMessage(), "defeated all the enemies");
	}
	
	@Test
	void testCompoundMessageCorrect() {
		Goal exit = new MazeGoal();
		Goal bdrs = new BouldersGoal();
		Goal enms = new EnemiesGoal();
		
		List<Goal> goalList = new ArrayList<Goal>();
		goalList.add(exit);
		goalList.add(bdrs);
		
		
		Goal simpleOr = new MultiGoalOr(goalList);
		
		List<Goal> goalList2 = new ArrayList<Goal>();
		goalList2.add(simpleOr);
		goalList2.add(enms);
		
		
		Goal topGoal = new MultiGoalAnd(goalList2);

		topGoal.notifyGoal("exit");
		topGoal.notifyGoal("enemies");
		
		assertEquals(topGoal.getMessage(), "found the exit to the maze and defeated all the enemies");
	}
}
